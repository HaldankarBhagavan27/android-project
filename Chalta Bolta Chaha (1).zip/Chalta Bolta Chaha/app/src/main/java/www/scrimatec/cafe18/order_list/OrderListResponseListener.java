package www.scrimatec.cafe18.order_list;

public interface OrderListResponseListener {
    void onOrderListResponseReceived();

    void onOrderListResponseFailed();

    void onOrderListResponseTimeout();
}
