package www.scrimatec.cafe18.profile;

import android.content.Context;
import android.os.Bundle;
import android.support.design.widget.TextInputLayout;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.github.ybq.android.spinkit.SpinKitView;
import www.scrimatec.cafe18.R;
import www.scrimatec.cafe18.utils.AppPreference;

//import uk.co.chrisjenx.calligraphy.CalligraphyContextWrapper;

public class UserProfileActivity extends AppCompatActivity implements View.OnClickListener, UpdateProfileResponseListener {
    private AppPreference preference;
    private TextInputLayout input_layout_FName, input_layout_Email, input_layout_mob, input_layout_addr;
    private EditText editFName, editEmail, editMob, editAddr;
    private Toolbar toolbar;
    private TextView txt_title;
    private ImageView img_back_arrow;
    private RelativeLayout lay_toolbar_cart;
    private String name, email, mobile, address;
    private Button btn_update;
    private ScrollView profile_scroll_view;
    private SpinKitView profile_loader;

//    @Override
//    protected void attachBaseContext(Context newBase) {
//        super.attachBaseContext(CalligraphyContextWrapper.wrap(newBase));
//    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        init();
        editFName.setText(preference.getName());
        editEmail.setText(preference.getEmail());
        editMob.setText(preference.getMobile());
        editAddr.setText(preference.getAddress());
        UserProfileManager.getInstance().registerUpdateProfileListener(this);
    }

    private void init() {
        preference = new AppPreference(this);
        toolbar = findViewById(R.id.app_bar);
        txt_title = toolbar.findViewById(R.id.txt_title);
        txt_title.setVisibility(View.VISIBLE);
        txt_title.setText(" My Profile");
        img_back_arrow = findViewById(R.id.img_back_arrow);
        img_back_arrow.setVisibility(View.VISIBLE);
        img_back_arrow.setOnClickListener(this);
        lay_toolbar_cart = toolbar.findViewById(R.id.lay_toolbar_cart);
        lay_toolbar_cart.setVisibility(View.INVISIBLE);
        btn_update = findViewById(R.id.btn_update);
        btn_update.setOnClickListener(this);
        profile_scroll_view = findViewById(R.id.profile_scroll_view);
        profile_loader = findViewById(R.id.profile_loader);

        input_layout_FName = findViewById(R.id.input_layout_FName);
        input_layout_Email = findViewById(R.id.input_layout_Email);
        input_layout_mob = findViewById(R.id.input_layout_mob);
        input_layout_addr = findViewById(R.id.input_layout_addr);

        editFName = findViewById(R.id.editFName);
        editEmail = findViewById(R.id.editEmail);
        editMob = findViewById(R.id.editMob);
        editAddr = findViewById(R.id.editAddr);

        editFName.addTextChangedListener(new MyTextWatcher(editFName));
        editEmail.addTextChangedListener(new MyTextWatcher(editEmail));
        editMob.addTextChangedListener(new MyTextWatcher(editMob));
        editAddr.addTextChangedListener(new MyTextWatcher(editAddr));

        img_back_arrow.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.img_back_arrow:
                finish();
                break;
            case R.id.btn_update:
                View view = this.getCurrentFocus();
                if (view != null) {
                    InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                    imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
                }
                if (!validateAddress()) {
                    return;
                }
                if (!validateEmail()) {
                    return;
                }
                if (!validateEmail()) {
                    return;
                }
                if (!validateAddress()) {
                    return;
                }
                name = editFName.getText().toString().trim();
                email = editEmail.getText().toString().trim();
                mobile = editMob.getText().toString().trim();
                address = editAddr.getText().toString().trim();
                UserProfileManager.getInstance().sendUpdateProfileRequest(UserProfileActivity.this, preference.getUserId(), name, mobile, address, email);
                profile_scroll_view.setVisibility(View.GONE);
                profile_loader.setVisibility(View.VISIBLE);
                btn_update.setVisibility(View.GONE);
                break;
        }
    }

    @Override
    public void onUpdateProfileResponseReceived() {
        Toast.makeText(this, "Profile updated successfully!", Toast.LENGTH_SHORT).show();
        profile_scroll_view.setVisibility(View.VISIBLE);
        profile_loader.setVisibility(View.GONE);
        btn_update.setVisibility(View.VISIBLE);
        preference.setName(name);
        preference.setEmail(email);
        preference.setAddress(address);
        preference.setMobile(mobile);
        editFName.setText(preference.getName());
        editEmail.setText(preference.getEmail());
        editMob.setText(preference.getMobile());
        editAddr.setText(preference.getAddress());
    }

    @Override
    public void onUpdateProfileResponseFailed() {
        btn_update.setVisibility(View.VISIBLE);
        profile_scroll_view.setVisibility(View.VISIBLE);
        profile_loader.setVisibility(View.GONE);
        Toast.makeText(UserProfileActivity.this, R.string.something_went_wrong, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onUpdateProfileTimeoutReceived() {
        btn_update.setVisibility(View.VISIBLE);
        profile_scroll_view.setVisibility(View.VISIBLE);
        profile_loader.setVisibility(View.GONE);
        Toast.makeText(UserProfileActivity.this, R.string.internet_connection_error, Toast.LENGTH_SHORT).show();
    }

    class MyTextWatcher implements TextWatcher {

        private View view;

        private MyTextWatcher(View view) {
            this.view = view;
        }

        public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
        }

        public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
        }

        public void afterTextChanged(Editable editable) {
            switch (view.getId()) {
                case R.id.input_layout_FName:
                    validateFirstName();
                    break;
                case R.id.input_layout_Email:
                    validateEmail();
                    break;
                case R.id.input_layout_mob:
                    validateMobile();
                    break;
                case R.id.input_layout_addr:
                    validateAddress();
                    break;
            }
        }
    }

    private boolean validateFirstName() {
        if (editFName.getText().toString().trim().isEmpty()) {
            input_layout_FName.setError("Please Enter Name");
            requestFocus(editFName);
            return false;
        } else {
            if (editFName.getText().toString().trim().length() > 2) {
                input_layout_FName.setErrorEnabled(false);
                return true;
            } else {
                input_layout_FName.setError("Invalid Name");
                requestFocus(editFName);
                return false;
            }
        }
    }

    private boolean validateMobile() {
        if (editMob.getText().toString().trim().isEmpty()) {
            input_layout_mob.setError("Please Enter Mobile Number");
            requestFocus(editMob);
            return false;
        } else {
            if (editMob.getText().toString().trim().length() == 10) {
                input_layout_mob.setErrorEnabled(false);
                return true;
            } else {
                input_layout_mob.setError("Invalid Mobile Number");
                requestFocus(editMob);
                return false;
            }
        }
    }

    private boolean validateEmail() {
        String emailPattern = "^[_A-Za-z0-9-]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";
        if (editEmail.getText().toString().trim().isEmpty()) {
            input_layout_Email.setError("Please Enter Email");
            requestFocus(editEmail);
            return false;
        } else {
            if (!editEmail.getText().toString().trim().matches(emailPattern)) {
                input_layout_Email.setError("Invalid Email Address");
                requestFocus(editEmail);
                return false;
            } else {
                input_layout_Email.setErrorEnabled(false);
            }
            return true;
        }
    }

    private boolean validateAddress() {
        if (editAddr.getText().toString().trim().isEmpty()) {
            input_layout_addr.setError("Please Enter Address");
            requestFocus(editAddr);
            return false;
        } else {
            if (editAddr.getText().toString().trim().length() > 3) {
                input_layout_addr.setErrorEnabled(false);
                return true;
            } else {
                input_layout_addr.setError("Invalid Address");
                requestFocus(editAddr);
                return false;
            }
        }
    }

    private void requestFocus(View view) {
        if (view.requestFocus()) {
            getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE);
        }
    }
}
