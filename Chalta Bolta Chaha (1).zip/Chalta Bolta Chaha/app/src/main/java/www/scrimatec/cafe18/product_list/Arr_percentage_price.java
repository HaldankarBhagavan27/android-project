package www.scrimatec.cafe18.product_list;

public class Arr_percentage_price {
    private String percentage;

    public String getPercentage() {
        return percentage;
    }

    public void setPercentage(String percentage) {
        this.percentage = percentage;
    }

    @Override
    public String toString() {
        return "ClassPojo [price = " + percentage + "]";
    }
}
