package www.scrimatec.cafe18.signup;

/**
 * Created by Softdroid on 10/10/2017.
 */

public interface OTPResponseListener {
    void onOTPResponseReceived();
    void onOTPResponseFailed();
    void onOTPResponseTimeout();
}
