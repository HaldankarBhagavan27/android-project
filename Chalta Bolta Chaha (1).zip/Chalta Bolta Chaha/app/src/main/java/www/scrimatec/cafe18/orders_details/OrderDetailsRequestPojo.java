package www.scrimatec.cafe18.orders_details;

public class OrderDetailsRequestPojo {
    private String invoice_num;

    public OrderDetailsRequestPojo(String invoice_num) {
        this.invoice_num = invoice_num;
    }

    public String getInvoice_num() {
        return invoice_num;
    }

    public void setInvoice_num(String invoice_num) {
        this.invoice_num = invoice_num;
    }
}
