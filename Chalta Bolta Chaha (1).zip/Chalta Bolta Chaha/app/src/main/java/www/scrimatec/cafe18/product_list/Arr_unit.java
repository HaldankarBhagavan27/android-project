package www.scrimatec.cafe18.product_list;

public class Arr_unit {
    private String unit;

    public String getUnit ()
    {
        return unit;
    }

    public void setUnit (String unit)
    {
        this.unit = unit;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [unit = "+unit+"]";
    }
}
