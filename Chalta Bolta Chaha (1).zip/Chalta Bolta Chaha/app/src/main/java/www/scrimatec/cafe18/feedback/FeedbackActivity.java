package www.scrimatec.cafe18.feedback;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.github.ybq.android.spinkit.SpinKitView;

import www.scrimatec.cafe18.R;
import www.scrimatec.cafe18.utils.AppPreference;

import java.text.SimpleDateFormat;
import java.util.Date;

//import uk.co.chrisjenx.calligraphy.CalligraphyContextWrapper;

public class FeedbackActivity extends AppCompatActivity implements FeedbackResponseListener, View.OnClickListener {
    private LinearLayout feedback_layout;
    private Button btn_submit;
    private SpinKitView feedback_progress_bar;
    private TextView txt_header;
    private EditText edt_sub, edt_message;
    private String sub, msg, date;
    private AppPreference appPreference;
    private Toolbar toolbar;
    private ImageView img_back_arrow;
    private TextView txt_title;
    private RelativeLayout lay_toolbar_cart;

//    @Override
//    protected void attachBaseContext(Context newBase) {
//        super.attachBaseContext(CalligraphyContextWrapper.wrap(newBase));
//    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_feedback);

        appPreference = new AppPreference(FeedbackActivity.this);
        feedback_layout = findViewById(R.id.feedback_layout);
        feedback_progress_bar = findViewById(R.id.feedback_progress_bar);
        btn_submit = findViewById(R.id.btn_submit);
        btn_submit.setOnClickListener(this);
        txt_header = findViewById(R.id.txt_header);
        edt_sub = findViewById(R.id.edt_sub);
        edt_message = findViewById(R.id.edt_message);
        toolbar = findViewById(R.id.app_bar);
        img_back_arrow = toolbar.findViewById(R.id.img_back_arrow);
        img_back_arrow.setVisibility(View.VISIBLE);
        img_back_arrow.setOnClickListener(this);
        txt_title = toolbar.findViewById(R.id.txt_title);
        txt_title.setText("Feedback");
        lay_toolbar_cart = toolbar.findViewById(R.id.lay_toolbar_cart);
        lay_toolbar_cart.setVisibility(View.INVISIBLE);
        date = new SimpleDateFormat("dd/MM/yyyy").format(new Date());
        FeedbackManager.getInstance().registerFeedbackListener(this);
    }

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.btn_submit) {
            sub = edt_sub.getText().toString().trim();
            msg = edt_message.getText().toString().trim();
            if (sub.length() > 5) {
                if (msg.length() > 5) {
                    FeedbackManager.getInstance().sendFeedbackRequest(FeedbackActivity.this, appPreference.getUserId(), sub, msg, date);
                    feedback_layout.setVisibility(View.GONE);
                    feedback_progress_bar.setVisibility(View.VISIBLE);
                    btn_submit.setVisibility(View.GONE);
                } else {
                    Toast.makeText(this, "enter details about matter", Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(this, "enter what you wanna talk about", Toast.LENGTH_SHORT).show();
            }
        } else if (v.getId() == R.id.img_back_arrow) {
            finish();
        }
    }

    @Override
    public void onFeedbackResponseReceived() {
        feedback_layout.setVisibility(View.VISIBLE);
        feedback_progress_bar.setVisibility(View.GONE);
        btn_submit.setVisibility(View.VISIBLE);
        Toast.makeText(this, "feedback submitted successfully", Toast.LENGTH_SHORT).show();
        finish();
    }

    @Override
    public void onFeedbackResponseFailed() {
        feedback_layout.setVisibility(View.VISIBLE);
        feedback_progress_bar.setVisibility(View.GONE);
        btn_submit.setVisibility(View.VISIBLE);
        Toast.makeText(this, "something went wrong\nplease try again", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onFeedbackResponseTimeout() {
        feedback_layout.setVisibility(View.VISIBLE);
        feedback_progress_bar.setVisibility(View.GONE);
        btn_submit.setVisibility(View.VISIBLE);
        Toast.makeText(this, "check internet connection", Toast.LENGTH_SHORT).show();
    }
}
