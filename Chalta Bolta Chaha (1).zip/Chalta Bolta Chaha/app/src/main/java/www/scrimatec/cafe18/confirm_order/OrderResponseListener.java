package www.scrimatec.cafe18.confirm_order;

public interface OrderResponseListener {
    void onOrderResponseReceived();

    void onOrderResponseFailed();

    void onOrderResponseTimeout();
}
