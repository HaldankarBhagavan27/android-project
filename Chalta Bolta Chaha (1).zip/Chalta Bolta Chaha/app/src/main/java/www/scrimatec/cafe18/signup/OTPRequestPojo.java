package www.scrimatec.cafe18.signup;

/**
 * Created by Softdroid on 10/10/2017.
 */

public class OTPRequestPojo {
    String mobile;

    public OTPRequestPojo(String mobile) {
        this.mobile = mobile;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }
}
