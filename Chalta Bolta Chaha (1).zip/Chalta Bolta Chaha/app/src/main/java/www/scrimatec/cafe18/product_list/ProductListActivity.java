package www.scrimatec.cafe18.product_list;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.support.design.widget.TabLayout;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import www.scrimatec.cafe18.R;
import www.scrimatec.cafe18.main.Cat_list;
import www.scrimatec.cafe18.main.MainActivity;
import www.scrimatec.cafe18.mycart.CartDatabaseHandler;
import www.scrimatec.cafe18.mycart.MyCartActivity;

import java.util.ArrayList;
import java.util.List;

//import uk.co.chrisjenx.calligraphy.CalligraphyContextWrapper;
import www.scrimatec.cafe18.utils.AppPreference;

public class ProductListActivity extends AppCompatActivity implements View.OnClickListener, ProductListAdapter.CallbackInterface {
    //    private ListView productList;
    //    private SpinKitView product_list_loader;
    private AppPreference preference;
    private int pos = 0;
    private String cat_id, name,moblie_no;
    private Toolbar toolbar;
    private ImageView img_back_arrow;
    private TextView txt_title, txt_cart_bubble;
    private RelativeLayout lay_toolbar_cart;
    private CartDatabaseHandler cartDatabaseHandler;

    private TabLayout tabLayout;
    private ViewPager viewPager;
    private Cat_list[] cat_list;
    ProductListFragment productListFragmentOne;
    ProductListFragment productListFragmentTwo;
    ProductListFragment productListFragmentThree;
    ProductListFragment productListFragmentFour;
    ProductListFragment productListFragmentFive;
    ProductListFragment productListFragmentSix;
    ProductListFragment productListFragmentSeven;
    ProductListFragment productListFragmentEight;
    ProductListFragment productListFragmentNine;
    ProductListFragment productListFragmentTen;
    ProductListFragment productListFragmentEleven;
    ProductListFragment productListFragmentTwelve;
    ProductListFragment productListFragmentThirteen;
    ProductListFragment productListFragmentFourteen;
    ProductListFragment productListFragmentFifteen;
    ProductListFragment productListFragmentSixteen;
    ProductListFragment productListFragmentSeventeen;
    ProductListFragment productListFragmentEighteen;
    ProductListFragment productListFragmentNineteen;
    ProductListFragment productListFragmentTwenty;

//    @Override
//    protected void attachBaseContext(Context newBase) {
//        super.attachBaseContext(CalligraphyContextWrapper.wrap(newBase));
//    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_product_list);

        preference = new AppPreference(this);
        pos = getIntent().getIntExtra("pos", 0);
        cat_id = getIntent().getStringExtra("id");
        name = getIntent().getStringExtra("name");
        moblie_no = preference.getMobile();
        cat_list = MainActivity.cat_list;
//        productList = (ListView) findViewById(R.id.productList);
//        product_list_loader = (SpinKitView) findViewById(R.id.product_list_loader);
        toolbar = findViewById(R.id.app_bar);
        img_back_arrow = toolbar.findViewById(R.id.img_back_arrow);
        img_back_arrow.setVisibility(View.VISIBLE);
        img_back_arrow.setOnClickListener(this);
        txt_title = toolbar.findViewById(R.id.txt_title);
//        txt_title.setText(name);
        txt_title.setText("Products");
        lay_toolbar_cart = toolbar.findViewById(R.id.lay_toolbar_cart);
        lay_toolbar_cart.setOnClickListener(this);
        txt_cart_bubble = toolbar.findViewById(R.id.txt_cart_bubble);
        cartDatabaseHandler = new CartDatabaseHandler(ProductListActivity.this);

//        ProductListManager.getInstance().registerProductListListener(this);
//        ProductListManager.getInstance().sendProductListRequest(ProductListActivity.this, cat_id);
//        productList.setVisibility(View.GONE);
//        product_list_loader.setVisibility(View.VISIBLE);

        viewPager = findViewById(R.id.viewpager);
//        viewPager.setOffscreenPageLimit(3);

        //Initializing the tablayout
        tabLayout = findViewById(R.id.tablayout);
        tabLayout.setupWithViewPager(viewPager);

        viewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

            }

            @Override
            public void onPageSelected(int position) {
                viewPager.setCurrentItem(position, false);

            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });
        Log.d("TAGG", "test log");
        List<String> titles = new ArrayList<>();
        List<String> titles_img = new ArrayList<>();
        final ViewPagerAdapter adapter = new ViewPagerAdapter(getSupportFragmentManager());
        Log.d("TAGG", "cat_list : " + cat_list.length);
        if (cat_list.length >= 1) {
            productListFragmentOne = new ProductListFragment(cat_list[0].getId(),moblie_no);
            adapter.addFragment(productListFragmentOne, cat_list[0].getName());
            titles.add(cat_list[0].getName());
        }
        if (cat_list.length >= 2) {
            productListFragmentTwo = new ProductListFragment(cat_list[1].getId(),moblie_no);
            adapter.addFragment(productListFragmentTwo, cat_list[1].getName());
            titles.add(cat_list[1].getName());
        }
        if (cat_list.length >= 3) {
            productListFragmentThree = new ProductListFragment(cat_list[2].getId(),moblie_no);
            adapter.addFragment(productListFragmentThree, cat_list[2].getName());
            titles.add(cat_list[2].getName());
        }
        if (cat_list.length >= 4) {
            productListFragmentFour = new ProductListFragment(cat_list[3].getId(),moblie_no);
            adapter.addFragment(productListFragmentFour, cat_list[3].getName());
            titles.add(cat_list[3].getName());
        }
        if (cat_list.length >= 5) {
            productListFragmentFive = new ProductListFragment(cat_list[4].getId(),moblie_no);
            adapter.addFragment(productListFragmentFive, cat_list[4].getName());
            titles.add(cat_list[4].getName());
        }
        if (cat_list.length >= 6) {
            productListFragmentSix = new ProductListFragment(cat_list[5].getId(),moblie_no);
            adapter.addFragment(productListFragmentSix, cat_list[5].getName());
            titles.add(cat_list[5].getName());
        }
        if (cat_list.length >= 7) {
            productListFragmentSeven = new ProductListFragment(cat_list[6].getId(),moblie_no);
            adapter.addFragment(productListFragmentSeven, cat_list[6].getName());
            titles.add(cat_list[6].getName());
        }
        if (cat_list.length >= 8) {
            productListFragmentEight = new ProductListFragment(cat_list[7].getId(),moblie_no);
            adapter.addFragment(productListFragmentEight, cat_list[7].getName());
            titles.add(cat_list[7].getName());
        }
        if (cat_list.length >= 9) {
            productListFragmentNine = new ProductListFragment(cat_list[8].getId(),moblie_no);
            adapter.addFragment(productListFragmentNine, cat_list[8].getName());
            titles.add(cat_list[8].getName());
        }
        if (cat_list.length >= 10) {
            productListFragmentTen = new ProductListFragment(cat_list[9].getId(),moblie_no);
            adapter.addFragment(productListFragmentTen, cat_list[9].getName());
            titles.add(cat_list[9].getName());
        }
        if (cat_list.length >= 11) {
            productListFragmentEleven = new ProductListFragment(cat_list[10].getId(),moblie_no);
            adapter.addFragment(productListFragmentEleven, cat_list[10].getName());
            titles.add(cat_list[10].getName());
        }
        if (cat_list.length >= 12) {
            productListFragmentTwelve = new ProductListFragment(cat_list[11].getId(),moblie_no);
            adapter.addFragment(productListFragmentTwelve, cat_list[11].getName());
            titles.add(cat_list[11].getName());
        }
        if (cat_list.length >= 13) {
            productListFragmentThirteen = new ProductListFragment(cat_list[12].getId(),moblie_no);
            adapter.addFragment(productListFragmentThirteen, cat_list[12].getName());
        }
        if (cat_list.length >= 14) {
            productListFragmentFourteen = new ProductListFragment(cat_list[13].getId(),moblie_no);
            adapter.addFragment(productListFragmentFourteen, cat_list[13].getName());
        }
        if (cat_list.length >= 15) {
            productListFragmentFifteen = new ProductListFragment(cat_list[14].getId(),moblie_no);
            adapter.addFragment(productListFragmentFifteen, cat_list[14].getName());
        }
        if (cat_list.length >= 16) {
            productListFragmentSixteen = new ProductListFragment(cat_list[15].getId(),moblie_no);
            adapter.addFragment(productListFragmentSixteen, cat_list[15].getName());
        }
        if (cat_list.length >= 17) {
            productListFragmentSeventeen = new ProductListFragment(cat_list[16].getId(),moblie_no);
            adapter.addFragment(productListFragmentSeventeen, cat_list[16].getName());
        }
        if (cat_list.length >= 18) {
            productListFragmentEighteen = new ProductListFragment(cat_list[17].getId(),moblie_no);
            adapter.addFragment(productListFragmentEighteen, cat_list[17].getName());
        }
        if (cat_list.length >= 19) {
            productListFragmentNineteen = new ProductListFragment(cat_list[18].getId(),moblie_no);
            adapter.addFragment(productListFragmentNineteen, cat_list[18].getName());
        }
        if (cat_list.length >= 20) {
            productListFragmentTwenty = new ProductListFragment(cat_list[19].getId(),moblie_no);
            adapter.addFragment(productListFragmentTwenty, cat_list[19].getName());
        }
        for (int i = 0; i < titles.size(); i++) {
            Log.d("TAGG1", "titles : " + i + "--> " + titles.get(i));
        }
        for (String module : titles) {
            tabLayout.addTab(tabLayout.newTab().setText(module));
        }

        tabLayout.post(new Runnable() {
            @Override
            public void run() {
                DisplayMetrics displayMetrics = new DisplayMetrics();
                ProductListActivity.this.getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
                int widthS = displayMetrics.widthPixels;
                tabLayout.measure(View.MeasureSpec.UNSPECIFIED, View.MeasureSpec.UNSPECIFIED);
                int widthT = tabLayout.getMeasuredWidth();

                if (widthS > widthT) {
                    tabLayout.setTabMode(TabLayout.MODE_FIXED);
                    tabLayout.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,
                            LinearLayout.LayoutParams.WRAP_CONTENT));
                }
            }
        });
        viewPager.setAdapter(adapter);
        new Handler().postDelayed(
                new Runnable() {
                    @Override
                    public void run() {
                        viewPager.setCurrentItem(pos, true);
                        tabLayout.getTabAt(pos).select();
                    }
                }, 100);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (cartDatabaseHandler.getCartCount() == 0)
            txt_cart_bubble.setVisibility(View.GONE);
        else {
            txt_cart_bubble.setVisibility(View.VISIBLE);
            txt_cart_bubble.setText(String.valueOf(cartDatabaseHandler.getCartCount()));
        }
    }

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.lay_toolbar_cart) {
            if (cartDatabaseHandler.getCartCount() > 0) {
                Intent intent = new Intent(ProductListActivity.this, MyCartActivity.class);
                startActivity(intent);
            } else {
                Toast.makeText(this, "Nothing in Basket", Toast.LENGTH_SHORT).show();
            }
        } else if (v.getId() == R.id.img_back_arrow) {
            finish();
            finish();
        }
    }

    @Override
    public void onHandleSelection() {
        if (cartDatabaseHandler.getCartCount() == 0) {
            txt_cart_bubble.setVisibility(View.GONE);
        } else {
            txt_cart_bubble.setVisibility(View.VISIBLE);
            txt_cart_bubble.setText(String.valueOf(cartDatabaseHandler.getCartCount()));
        }
    }

}
