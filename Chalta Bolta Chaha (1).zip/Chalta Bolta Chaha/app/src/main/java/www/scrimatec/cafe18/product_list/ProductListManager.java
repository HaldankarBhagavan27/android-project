package www.scrimatec.cafe18.product_list;

import android.content.Context;

import com.android.volley.Request;
import com.google.gson.Gson;
import www.scrimatec.cafe18.network.NetworkManager;
import www.scrimatec.cafe18.network.NetworkResponseListener;

import org.json.JSONException;
import org.json.JSONObject;

public class ProductListManager implements NetworkResponseListener {
    private static ProductListManager mInstance;
    private ProductListResponseListener mProductListResponseListener;
    private ProductListResponsePojo mProductListResponsePojo;

    public static ProductListManager getInstance() {
        return (mInstance == null) ? mInstance = new ProductListManager() : mInstance;
    }

    public void registerProductListListener(ProductListResponseListener productListResponseListener) {
        NetworkManager.getInstance().registerListener(this);
        mProductListResponseListener = productListResponseListener;
    }

    public void deregisterLoginListener() {
        NetworkManager.getInstance().deRegisterListener(this);
        mProductListResponseListener = null;
    }

    public void sendProductListRequest(Context context, String categoryId) {
        Gson gson = new Gson();
        ProductListRequestPojo productListRequestPojo = new ProductListRequestPojo(categoryId);
        JSONObject jsonObject = null;
        try {
            jsonObject = new JSONObject(gson.toJson(productListRequestPojo));
        } catch (JSONException e) {
            e.printStackTrace();
        }
        NetworkManager.getInstance().sendJsonObjectRequest(context, Request.Method.POST, NetworkManager.getInstance().getProductUrl(), jsonObject, NetworkManager.RequestType.PROD_LIST);
    }

    public ProductListResponsePojo getmProductListResponsePojo() {
        return mProductListResponsePojo;
    }

    @Override
    public void onNetworkResponseReceived(String response, NetworkManager.RequestType requestType) {
        Gson gson = new Gson();
        if (requestType == NetworkManager.RequestType.PROD_LIST) {
            if (mProductListResponseListener == null)
                return;
            mProductListResponsePojo = gson.fromJson(response, ProductListResponsePojo.class);
            if (!mProductListResponsePojo.getProd_list().isEmpty()) {
                mProductListResponseListener.onProductListResponseReceived();
            } else {
                mProductListResponseListener.onProductListResponseFailed();
            }
        }
    }

    @Override
    public void onNetworkResponseFailed(NetworkManager.RequestType requestType) {
        if (requestType == NetworkManager.RequestType.PROD_LIST) {
            mProductListResponseListener.onProductListResponseTimeout();
        }
    }
}

