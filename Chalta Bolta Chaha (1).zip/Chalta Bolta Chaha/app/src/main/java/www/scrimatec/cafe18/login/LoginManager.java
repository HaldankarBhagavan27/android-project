package www.scrimatec.cafe18.login;

import android.content.Context;

import com.android.volley.Request;
import com.google.gson.Gson;
import www.scrimatec.cafe18.network.NetworkManager;
import www.scrimatec.cafe18.network.NetworkResponseListener;

import org.json.JSONException;
import org.json.JSONObject;

public class LoginManager implements NetworkResponseListener {
    private static LoginManager mInstance;
    private LoginResponseListener mLoginResponseListener;
    private LoginResponsePojo mLoginResponsePojo;

    public static LoginManager getInstance() {
        return (mInstance == null) ? mInstance = new LoginManager() : mInstance;
    }

    public void registerLoginListener(LoginResponseListener loginResponseListener) {
        NetworkManager.getInstance().registerListener(this);
        mLoginResponseListener = loginResponseListener;
    }

    public void deregisterLoginListener() {
        NetworkManager.getInstance().deRegisterListener(this);
        mLoginResponseListener = null;
    }

    public void sendLoginRequest(Context context, String mobile, String password, String flag) {
        Gson gson = new Gson();
        LoginRequestPojo loginRequestPojo = new LoginRequestPojo(mobile, password, flag);
        JSONObject jsonObject = null;
        try {
            jsonObject = new JSONObject(gson.toJson(loginRequestPojo));
        } catch (JSONException e) {
            e.printStackTrace();
        }
        NetworkManager.getInstance().sendJsonObjectRequest(context, Request.Method.POST, NetworkManager.getInstance().getLoginUrl(), jsonObject, NetworkManager.RequestType.LOGIN);
    }

    public LoginResponsePojo getmLoginResponsePojo() {
        return mLoginResponsePojo;
    }

    @Override
    public void onNetworkResponseReceived(String response, NetworkManager.RequestType requestType) {
        Gson gson = new Gson();
        if (requestType == NetworkManager.RequestType.LOGIN) {
            mLoginResponsePojo = gson.fromJson(response, LoginResponsePojo.class);
            if (mLoginResponsePojo != null) {
                if (mLoginResponsePojo.getSt().equals("1")) {
                    mLoginResponseListener.onLoginResponseReceived();
                } else if (mLoginResponsePojo.getSt().equals("2")) {
                    mLoginResponseListener.onUserNotExist();
                } else {
                    mLoginResponseListener.onLoginResponseFailed();
                }
            }
        }
    }

    @Override
    public void onNetworkResponseFailed(NetworkManager.RequestType requestType) {
        if (requestType == NetworkManager.RequestType.LOGIN) {
            mLoginResponseListener.onLoginTimeoutReceived();
        }
    }
}
