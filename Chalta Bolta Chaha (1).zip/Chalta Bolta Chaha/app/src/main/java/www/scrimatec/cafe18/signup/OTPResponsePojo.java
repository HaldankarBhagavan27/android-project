package www.scrimatec.cafe18.signup;

/**
 * Created by Softdroid on 10/10/2017.
 */

public class OTPResponsePojo {
    String st, otp, msg;

    public String getSt() {
        return st;
    }

    public void setSt(String st) {
        this.st = st;
    }

    public String getOtp() {
        return otp;
    }

    public void setOtp(String otp) {
        this.otp = otp;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }
}
