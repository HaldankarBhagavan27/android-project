package www.scrimatec.cafe18.confirm_order;

import android.content.Context;

import com.android.volley.Request;
import com.google.gson.Gson;
import www.scrimatec.cafe18.network.NetworkManager;
import www.scrimatec.cafe18.network.NetworkResponseListener;

import org.json.JSONException;
import org.json.JSONObject;

public class OrderManager implements NetworkResponseListener {
    private static OrderManager mInstance;
    private OrderResponseListener mOrderResponseListener;
    private OrderResponsePojo mOrderResponsePojo;
    private AreaResponseListener mAreaResponseListener;
    private AreaResponsePojo mAreaResponsePojo;

    public static OrderManager getInstance() {
        return (mInstance == null) ? mInstance = new OrderManager() : mInstance;
    }

    public void registerOrderListener(OrderResponseListener orderResponseListener) {
        NetworkManager.getInstance().registerListener(this);
        mOrderResponseListener = orderResponseListener;
    }

    public void registerAreaListener(AreaResponseListener areaResponseListener) {
        NetworkManager.getInstance().registerListener(this);
        mAreaResponseListener = areaResponseListener;
    }

    public void deregisterOrderListener() {
        NetworkManager.getInstance().deRegisterListener(this);
        mOrderResponseListener = null;
    }

    public void sendOrderRequest(Context context, String pid, String price, String quantity, String name, String mob, String addr, String date, String userid, String delivery_charges, String tax) {
        Gson gson = new Gson();
        OrderRequestPojo orderRequestPojo = new OrderRequestPojo(pid, price, quantity, name, mob, addr, date, userid, delivery_charges, tax);
        JSONObject jsonObject = null;
        try {
            jsonObject = new JSONObject(gson.toJson(orderRequestPojo));
        } catch (JSONException e) {
            e.printStackTrace();
        }
        NetworkManager.getInstance().sendJsonObjectRequest(context, Request.Method.POST, NetworkManager.getInstance().getOrderUrl(), jsonObject, NetworkManager.RequestType.ORDER);
    }

    public void sendAreaRequest(Context context) {
        NetworkManager.getInstance().sendJsonObjectRequest(context, Request.Method.POST, NetworkManager.getInstance().getAreaUrl(), null, NetworkManager.RequestType.AREA);
    }

    public AreaResponsePojo getmAreaResponsePojo(){
        return mAreaResponsePojo;
    }

    @Override
    public void onNetworkResponseReceived(String response, NetworkManager.RequestType requestType) {
        Gson gson = new Gson();
        if (requestType == NetworkManager.RequestType.ORDER) {
            if (mOrderResponseListener == null)
                return;
            mOrderResponsePojo = gson.fromJson(response, OrderResponsePojo.class);
            if (mOrderResponsePojo.getSt().equals("1")) {
                mOrderResponseListener.onOrderResponseReceived();
            } else {
                mOrderResponseListener.onOrderResponseFailed();
            }
        } else if (requestType == NetworkManager.RequestType.AREA) {
            if (mAreaResponseListener == null)
                return;
            mAreaResponsePojo = gson.fromJson(response, AreaResponsePojo.class);
            if (mAreaResponsePojo.getSt().equals("1")) {
                mAreaResponseListener.onAreaResponseReceived();
            } else {
                mAreaResponseListener.onAreaResponseFailed();
            }
        }
    }

    @Override
    public void onNetworkResponseFailed(NetworkManager.RequestType requestType) {
        if (requestType == NetworkManager.RequestType.ORDER) {
            mOrderResponseListener.onOrderResponseTimeout();
        }
    }
}