package www.scrimatec.cafe18.mycart;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import www.scrimatec.cafe18.R;
import www.scrimatec.cafe18.confirm_order.OrderConfirmationActivity;

import java.util.ArrayList;

//import uk.co.chrisjenx.calligraphy.CalligraphyContextWrapper;

public class MyCartActivity extends AppCompatActivity implements View.OnClickListener, QuantityUpdateListener {
    private static LinearLayout lay_order;
    private Button btn_confirm_order;
    private static ListView cart_list;
    private static TextView txt_total_price;
    private CartDatabaseHandler cartDatabaseHandler;
    private MyCartAdapter myCartAdapter;
    private ArrayList<Cart> carts;
    private double total;
    private static Context context;
    private Toolbar toolbar;
    private ImageView img_back_arrow;
    private TextView txt_title;
    private RelativeLayout lay_toolbar_cart;

//    @Override
//    protected void attachBaseContext(Context newBase) {
//        super.attachBaseContext(CalligraphyContextWrapper.wrap(newBase));
//    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cart);

        lay_order = findViewById(R.id.lay_order);
        btn_confirm_order = findViewById(R.id.btn_confirm_order);
        txt_total_price = findViewById(R.id.txt_total_price);
        btn_confirm_order.setOnClickListener(this);
        context = MyCartActivity.this;
        cart_list = findViewById(R.id.cart_list);
        toolbar = findViewById(R.id.app_bar);
        img_back_arrow = toolbar.findViewById(R.id.img_back_arrow);
        img_back_arrow.setVisibility(View.VISIBLE);
        img_back_arrow.setOnClickListener(this);
        txt_title = toolbar.findViewById(R.id.txt_title);
        txt_title.setText("My Basket");
        lay_toolbar_cart = toolbar.findViewById(R.id.lay_toolbar_cart);
        lay_toolbar_cart.setVisibility(View.INVISIBLE);

        cartDatabaseHandler = new CartDatabaseHandler(MyCartActivity.this);
    }

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.btn_confirm_order) {
            Intent intent = new Intent(MyCartActivity.this, OrderConfirmationActivity.class);
            intent.putExtra("total", total);
            startActivity(intent);
        } else if (v.getId() == R.id.img_back_arrow) {
            finish();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        carts = new ArrayList<>();
        total = 0;
        carts = cartDatabaseHandler.getAllProducts();
        if (carts.size() == 0) {
            Toast.makeText(this, "Nothing in Basket", Toast.LENGTH_SHORT).show();
            finish();
        } else {
            myCartAdapter = new MyCartAdapter(MyCartActivity.this, carts, this);
            cart_list.setAdapter(myCartAdapter);
            for (int i = 0; i < carts.size(); i++) {
                Log.d("TAGG", "Integer.valueOf(carts.get(i).getPrice(): " + carts.get(i).getPrice());
                Log.d("TAGG", "Integer.valueOf(carts.get(i).getQty(): " + carts.get(i).getQty());
                total = total + (Double.valueOf(Double.valueOf(carts.get(i).getPrice()) * Integer.valueOf(carts.get(i).getQty())));
            }
            txt_total_price.setText("Total: ₹ " + total);
        }
    }

    public static void updateTotalPrice(String totalPrice) {
        if (!totalPrice.equals("0")) {
            txt_total_price.setText("Total: ₹ " + totalPrice);
        } else {
            Toast.makeText(context, "Basket is empty", Toast.LENGTH_SHORT).show();
            lay_order.setVisibility(View.GONE);
            cart_list.setVisibility(View.GONE);
        }
    }

    @Override
    public void onQuantityChanged() {
        total = 0;
        carts = cartDatabaseHandler.getAllProducts();
        for (int i = 0; i < carts.size(); i++) {
            total = total + (Double.valueOf(carts.get(i).getPrice()) * Integer.valueOf(carts.get(i).getQty()));
        }
        if (carts.size() == 0) {
            total = 0;
        }
        MyCartActivity.updateTotalPrice(String.valueOf(total));
    }
}
