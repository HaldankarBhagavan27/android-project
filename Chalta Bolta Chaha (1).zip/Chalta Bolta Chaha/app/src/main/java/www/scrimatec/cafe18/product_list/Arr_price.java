package www.scrimatec.cafe18.product_list;

public class Arr_price {
    private String price;

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    @Override
    public String toString() {
        return "ClassPojo [price = " + price + "]";
    }
}
