package www.scrimatec.cafe18.confirm_order;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.github.paolorotolo.expandableheightlistview.ExpandableHeightListView;

import www.scrimatec.cafe18.R;
import www.scrimatec.cafe18.main.MainActivity;
import www.scrimatec.cafe18.mycart.Cart;
import www.scrimatec.cafe18.mycart.CartDatabaseHandler;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

//import uk.co.chrisjenx.calligraphy.CalligraphyContextWrapper;

public class InvoiceActivity extends AppCompatActivity {
    ArrayList<Cart> cartList;
    private CartDatabaseHandler cartDatabaseHandler;
    private Button btn_,btn_upi;
    private InvoiceAdapter invoiceAdapter;
    private TextView txt_name, txt_addr, txt_total, txt_date, txt_delivery;
    private double total = 0, delivery = 0;
    private String name, address;

//    @Override
//    protected void attachBaseContext(Context newBase) {
//        super.attachBaseContext(CalligraphyContextWrapper.wrap(newBase));
//    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_invoice);

        name = getIntent().getStringExtra("name");
        address = getIntent().getStringExtra("address");
        delivery = getIntent().getIntExtra("delivery", 0);
        cartList = new ArrayList<Cart>();
        cartDatabaseHandler = new CartDatabaseHandler(InvoiceActivity.this);
        cartList = cartDatabaseHandler.getAllProducts();
        cartDatabaseHandler.clearCart();
        txt_date = findViewById(R.id.txt_date);
        btn_upi = findViewById(R.id.upipay);
        txt_total = findViewById(R.id.txt_total);
        txt_delivery = findViewById(R.id.txt_delivery);
        txt_name = findViewById(R.id.txt_name);
        txt_name.setText("Name : " + name);
        txt_addr = findViewById(R.id.txt_addr);
        txt_addr.setText("Delivery Address : " + address);
        txt_date.setText("Date : " + new SimpleDateFormat("dd/MM/yyyy").format(new Date()));
        ExpandableHeightListView expandableListView = findViewById(R.id.expandable_listview);
        invoiceAdapter = new InvoiceAdapter(InvoiceActivity.this, cartList);
        expandableListView.setAdapter(invoiceAdapter);
        expandableListView.setExpanded(true);
        expandableListView.setFocusable(false);
        final String payeeAddress = "9870545488@ybl";
        final String payeeName = "Rajendra Nanavare";
        final String transactionNote = "Extreme Sportswear";
        final String currencyUnit = "INR";

        for (int i = 0; i < cartList.size(); i++) {
            total = total + (Double.valueOf(cartList.get(i).getPrice()) * Integer.valueOf(cartList.get(i).getQty()));
        }
        txt_delivery.setText("₹ " + delivery);
        txt_total.setText("₹ " + (total + delivery));
        btn_upi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Uri uri = Uri.parse("upi://pay?pa=" + payeeAddress + "&pn=" + payeeName + "&tn=" + transactionNote +
                        "&am=" + total + "&cu=" + currencyUnit);

                //Toast.makeText(InvoiceActivity.this, "", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(Intent.ACTION_VIEW, uri);
                startActivityForResult(intent, 1);
            }
        });

    }

    @Override
    public void onBackPressed() {
        Intent intent = new Intent(InvoiceActivity.this, MainActivity.class);
        startActivity(intent);
        finish();
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {

        //   Toast.makeText(this, "onActivityResult: requestCode: " + requestCode, Toast.LENGTH_SHORT).show();
        //Toast.makeText(this, "onActivityResult: resultCode: ", Toast.LENGTH_SHORT).show();
//        Log.d(TAG, );
//        Log.d(TAG, "onActivityResult: resultCode: "+resultCode);
        //txnId=UPI20b6226edaef4c139ed7cc38710095a3&responseCode=00&ApprovalRefNo=null&Status=SUCCESS&txnRef=undefined
        //txnId=UPI608f070ee644467aa78d1ccf5c9ce39b&responseCode=ZM&ApprovalRefNo=null&Status=FAILURE&txnRef=undefined

        if (data != null) {
           // Toast.makeText(this, "onActivityResult: data: " + data.getStringExtra("response"), Toast.LENGTH_SHORT).show();
            // Log.d(TAG, "onActivityResult: data: " + data.getStringExtra("response"));
            String res = data.getStringExtra("response");
            String search = "SUCCESS";
            if (res.toLowerCase().contains(search.toLowerCase()))
            {
                Toast.makeText(this, "Payment Successful", Toast.LENGTH_SHORT).show();
            }
            else
            {
                Toast.makeText(this, "Payment Failed", Toast.LENGTH_SHORT).show();
            }
        }


    }

}