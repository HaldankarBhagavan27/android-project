package www.scrimatec.cafe18.main;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.android.volley.toolbox.ImageLoader;
import www.scrimatec.cafe18.R;
import www.scrimatec.cafe18.utils.MandaiController;

public class CategoryAdapter extends RecyclerView.Adapter<RecyclerViewHolders> {
    private Cat_list[] cat_list;
    private Context context;
    private ImageLoader imageLoader = MandaiController.getInstance().getImageLoader();

    public CategoryAdapter(Context context, Cat_list[] cat_list) {
        this.context = context;
        this.cat_list = cat_list;
        this.context = context;
    }

    @Override
    public RecyclerViewHolders onCreateViewHolder(ViewGroup parent, int viewType) {
        View layoutView = LayoutInflater.from(parent.getContext()).inflate(R.layout.category_row, null);
        RecyclerViewHolders rcv = new RecyclerViewHolders(layoutView);
        return rcv;
    }

    @Override
    public void onBindViewHolder(RecyclerViewHolders holder, int position) {
        holder.txt_cat.setText(cat_list[position].getName() +" / " + cat_list[position].getMar_name());
        holder.img_cat.setImageUrl(cat_list[position].getImg_url().replace("https:scrimatec.com/milk_bar/and_admin", "https://muthabrothers.com/and_admin"), imageLoader);
    }

    @Override
    public int getItemCount() {
        return this.cat_list.length;
    }
}