package www.scrimatec.cafe18.orders_details;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import www.scrimatec.cafe18.R;

public class OrderDetailsAdapter extends BaseAdapter {
    private Context context;
    private Order_details[] order_details;
    private LayoutInflater mLayoutInflater;

    public OrderDetailsAdapter(Context context, Order_details[] order_details) {
        this.context = context;
        this.order_details = order_details;
        mLayoutInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount() {
        return order_details.length;
    }

    @Override
    public Object getItem(int position) {
        return order_details[position];
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        ViewHolder holder = null;
        if (convertView == null) {
            holder = new ViewHolder();
            convertView = mLayoutInflater.inflate(R.layout.order_details_row_layout, parent, false);
            convertView.setTag(holder);
            holder.txt_sr = convertView.findViewById(R.id.txt_sr);
            holder.txt_name = convertView.findViewById(R.id.txt_name);
            holder.txt_price = convertView.findViewById(R.id.txt_price);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }

        holder.txt_sr.setText(String.valueOf((position + 1)));
        holder.txt_name.setText(order_details[position].getPname());
        holder.txt_price.setText("₹ " + Double.valueOf(order_details[position].getPrice()) * Integer.valueOf(order_details[position].getQuantity()));
        return convertView;
    }

    private class ViewHolder {
        private TextView txt_sr, txt_name, txt_price;
    }
}