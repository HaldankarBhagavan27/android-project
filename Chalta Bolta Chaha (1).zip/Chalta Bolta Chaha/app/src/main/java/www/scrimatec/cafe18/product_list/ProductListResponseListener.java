package www.scrimatec.cafe18.product_list;

public interface ProductListResponseListener {
    void onProductListResponseReceived();

    void onProductListResponseFailed();

    void onProductListResponseTimeout();
}
