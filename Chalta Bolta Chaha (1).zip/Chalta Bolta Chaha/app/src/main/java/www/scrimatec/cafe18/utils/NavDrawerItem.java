package www.scrimatec.cafe18.utils;

public class NavDrawerItem {
    private int mDrawerIcon;
    private String mDrawerText;
    private String title;
    private boolean isSpinner;

    public NavDrawerItem(int drawerIcon, String drawerText) {
        this.mDrawerIcon = drawerIcon;
        this.mDrawerText = drawerText;
    }

    public NavDrawerItem(String title) {
        this.title = title;
    }

    public NavDrawerItem(boolean isSpinner) {
        this.isSpinner = isSpinner;
    }

    public boolean isSpinner() {
        return isSpinner;
    }

    public void setIsSpinner(boolean isSpinner) {
        this.isSpinner = isSpinner;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public int getDrawerIcon() {
        return mDrawerIcon;
    }

    public void setDrawerIcon(int DrawerIcon) {
        this.mDrawerIcon = DrawerIcon;
    }

    public String getDrawerText() {
        return mDrawerText;
    }

    public void setDrawerText(String DrawerText) {
        this.mDrawerText = DrawerText;
    }
}
