package www.scrimatec.cafe18.login;

public class LoginResponsePojo {
    private Data[] data;

    private String st;

    public Data[] getData() {
        return data;
    }

    public void setData(Data[] data) {
        this.data = data;
    }

    public String getSt() {
        return st;
    }

    public void setSt(String st) {
        this.st = st;
    }

    @Override
    public String toString() {
        return "ClassPojo [data = " + data + ", st = " + st + "]";
    }
}
