package www.scrimatec.cafe18.product_list;

public class Arr_quant {
    private String quant;

    public String getQuant ()
    {
        return quant;
    }

    public void setQuant (String quant)
    {
        this.quant = quant;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [quant = "+quant+"]";
    }
}
