package www.scrimatec.cafe18.mycart;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.util.ArrayList;

public class CartDatabaseHandler extends SQLiteOpenHelper {
    private static final int DATABASE_VERSION = 1;
    private static final String DATABASE_NAME = "mutha";
    private static final String TABLE_CART = "cart";
    private static final String KEY_ID = "id";
    private static final String KEY_PNAME = "name";
    private static final String KEY_PID = "pid";
    private static final String KEY_URL = "url";
    private static final String KEY_QTY = "qty";
    private static final String KEY_UNIT = "unit";
    private static final String KEY_PRICE = "price";

    public CartDatabaseHandler(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_CART_TABLE = "CREATE TABLE "
                + TABLE_CART
                + "("
                + KEY_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + KEY_PID + " TEXT,"
                + KEY_PNAME + " TEXT,"
                + KEY_URL + " TEXT,"
                + KEY_QTY + " TEXT,"
                + KEY_UNIT + " TEXT,"
                + KEY_PRICE + " TEXT"
                + ")";
        db.execSQL(CREATE_CART_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_CART);
        onCreate(db);
    }

    public void addToCart(Cart cart) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(KEY_PID, cart.getProdId());
        values.put(KEY_PNAME, cart.getPname());
        values.put(KEY_URL, cart.getUrl());
        values.put(KEY_QTY, cart.getQty());
        values.put(KEY_UNIT, cart.getUnit());
        values.put(KEY_PRICE, cart.getPrice());
        db.insert(TABLE_CART, null, values);
        db.close();
    }

    public void updateProduct(Cart cart) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(KEY_QTY, cart.getQty());
//        values.put(KEY_PRICE, cart.getPrice());
        Log.d("TAGG12", "cart.getQty(): " + cart.getQty());
        Log.d("TAGG12", "cart.getPrice(): " + cart.getPrice());
        db.update(TABLE_CART, values, KEY_ID + "=" + cart.getId(), null);
        db.close();
    }

    public ArrayList<Cart> getAllProducts() {
        ArrayList<Cart> cartList = new ArrayList<Cart>();
        String selectQuery = "SELECT  * FROM " + TABLE_CART;
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);
        if (cursor.moveToFirst()) {
            do {
                Cart cart = new Cart();
                cart.setId(Integer.parseInt(cursor.getString(0)));
                cart.setProdId(cursor.getString(1));
                cart.setPname(cursor.getString(2));
                cart.setUrl(cursor.getString(3));
                cart.setQty(cursor.getString(4));
                cart.setUnit(cursor.getString(5));
                cart.setPrice(cursor.getString(6));
                cartList.add(cart);
            } while (cursor.moveToNext());
        }
        return cartList;
    }

    public void removeProduct(String id) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_CART, KEY_ID + " = ?", new String[]{id});
        db.close();
    }

    public int getCartCount() {
        int count = 0;
        String countQuery = "SELECT  * FROM " + TABLE_CART;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(countQuery, null);
        count = cursor.getCount();
        cursor.close();
        return count;
    }

    public void clearCart() {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_CART, null, null);
        db.close();
    }
}