package www.scrimatec.cafe18.orders_details;

public class OrderDetailsResponsePojo {
    private Order_details[] order_details;

    public Order_details[] getOrder_details() {
        return order_details;
    }

    public void setOrder_details(Order_details[] order_details) {
        this.order_details = order_details;
    }

    @Override
    public String toString() {
        return "ClassPojo [order_details = " + order_details + "]";
    }
}
