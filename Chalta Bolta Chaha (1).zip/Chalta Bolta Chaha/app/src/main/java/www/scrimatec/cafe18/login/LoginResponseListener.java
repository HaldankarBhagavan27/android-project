package www.scrimatec.cafe18.login;

public interface LoginResponseListener {
    void onLoginResponseReceived();

    void onLoginResponseFailed();

    void onLoginTimeoutReceived();

    void onUserNotExist();
}
