package www.scrimatec.cafe18.product_list;

public class Unit {
    private String prod_unit;

    public String getProd_unit ()
    {
        return prod_unit;
    }

    public void setProd_unit (String prod_unit)
    {
        this.prod_unit = prod_unit;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [prod_unit = "+prod_unit+"]";
    }
}
