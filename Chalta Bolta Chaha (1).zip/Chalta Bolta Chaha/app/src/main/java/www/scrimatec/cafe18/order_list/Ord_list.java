package www.scrimatec.cafe18.order_list;

public class Ord_list {
    private String id;

    private String date;

    private String invoice_num;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getInvoice_num() {
        return invoice_num;
    }

    public void setInvoice_num(String invoice_num) {
        this.invoice_num = invoice_num;
    }

    @Override
    public String toString() {
        return "ClassPojo [id = " + id + ", date = " + date + ", invoice_num = " + invoice_num + "]";
    }
}
