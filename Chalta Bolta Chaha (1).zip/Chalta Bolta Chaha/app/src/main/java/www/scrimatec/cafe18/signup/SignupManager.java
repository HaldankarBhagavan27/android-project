package www.scrimatec.cafe18.signup;

import android.content.Context;

import com.android.volley.Request;
import com.google.gson.Gson;
import www.scrimatec.cafe18.network.NetworkManager;
import www.scrimatec.cafe18.network.NetworkResponseListener;

import org.json.JSONException;
import org.json.JSONObject;

public class SignupManager implements NetworkResponseListener {
    private static SignupManager mInstance;
    private SignupResponseListener mSignupResponseListener;
    private SignupResponsePojo mSignupResponsePojo;
    private OTPResponseListener mOtpResponseListener;
    private OTPResponsePojo mOtpResponsePojo;

    public static SignupManager getInstance() {
        return (mInstance == null) ? mInstance = new SignupManager() : mInstance;
    }

    public void registerSignupListener(SignupResponseListener signupResponseListener) {
        NetworkManager.getInstance().registerListener(this);
        mSignupResponseListener = signupResponseListener;
    }

    public void registerOTPListener(OTPResponseListener otpResponseListener) {
        NetworkManager.getInstance().registerListener(this);
        mOtpResponseListener = otpResponseListener;
    }

    public void deregisterSignupListener() {
        NetworkManager.getInstance().deRegisterListener(this);
        mSignupResponseListener = null;
    }

    public void sendSignupRequest(Context context, String name, String email, String mob, String password, String address, String token) {
        Gson gson = new Gson();
        SignupRequestPojo signupRequestPojo = new SignupRequestPojo(name, email, mob, password, address, token);
        JSONObject jsonObject = null;
        try {
            jsonObject = new JSONObject(gson.toJson(signupRequestPojo));
        } catch (JSONException e) {
            e.printStackTrace();
        }
        NetworkManager.getInstance().sendJsonObjectRequest(context, Request.Method.POST, NetworkManager.getInstance().getSignupUrl(), jsonObject, NetworkManager.RequestType.SIGNUP);
    }

    public void sendOTPRequest(Context context, String mobile) {
        Gson gson = new Gson();
        OTPRequestPojo otpRequestPojo = new OTPRequestPojo(mobile);
        JSONObject jsonObject = null;
        try {
            jsonObject = new JSONObject(gson.toJson(otpRequestPojo));
        } catch (JSONException e) {
            e.printStackTrace();
        }
        NetworkManager.getInstance().sendJsonObjectRequest(context, Request.Method.POST, NetworkManager.getInstance().getOtpUrl(), jsonObject, NetworkManager.RequestType.OTP);
    }

    public SignupResponsePojo getmSignupResponsePojo() {
        return mSignupResponsePojo;
    }

    public OTPResponsePojo getmOtpResponsePojo() {
        return mOtpResponsePojo;
    }

    @Override
    public void onNetworkResponseReceived(String response, NetworkManager.RequestType requestType) {
        Gson gson = new Gson();
        if (requestType == NetworkManager.RequestType.SIGNUP) {
            if (mSignupResponseListener == null)
                return;
            mSignupResponsePojo = gson.fromJson(response, SignupResponsePojo.class);
            if (mSignupResponsePojo.getSt().equals("1")) {
                mSignupResponseListener.onSignupResponseReceived();
            } else if (mSignupResponsePojo.getSt().equals("2")) {
                mSignupResponseListener.onUserAlreadyExsist();
            } else {
                mSignupResponseListener.onSignupResponseFailed();
            }
        } else if (requestType == NetworkManager.RequestType.OTP) {
            if (mOtpResponseListener == null)
                return;
            mOtpResponsePojo = gson.fromJson(response, OTPResponsePojo.class);
            if (mOtpResponsePojo.getSt().equals("1")) {
                mOtpResponseListener.onOTPResponseReceived();
            } else {
                mOtpResponseListener.onOTPResponseFailed();
            }
        }
    }

    @Override
    public void onNetworkResponseFailed(NetworkManager.RequestType requestType) {
        if (requestType == NetworkManager.RequestType.SIGNUP) {
            mSignupResponseListener.onSignupResponseTimeout();
        } else if (requestType == NetworkManager.RequestType.OTP) {
            mOtpResponseListener.onOTPResponseTimeout();
        }
    }
}