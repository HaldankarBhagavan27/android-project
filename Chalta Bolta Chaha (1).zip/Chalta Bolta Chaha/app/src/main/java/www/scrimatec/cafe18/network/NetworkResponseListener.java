package www.scrimatec.cafe18.network;

public interface NetworkResponseListener {
    void onNetworkResponseReceived(String response, NetworkManager.RequestType requestType);

    void onNetworkResponseFailed(NetworkManager.RequestType requestType);
}
