package www.scrimatec.cafe18.mycart;

import android.app.Dialog;
import android.content.Context;
import android.graphics.drawable.ColorDrawable;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.toolbox.ImageLoader;
import com.android.volley.toolbox.NetworkImageView;

import java.util.ArrayList;

import www.scrimatec.cafe18.R;
import www.scrimatec.cafe18.utils.MandaiController;

public class MyCartAdapter extends BaseAdapter {
    private Context context;
    private ArrayList<Cart> carts;
    private LayoutInflater mLayoutInflater;
    private ImageLoader imageLoader = MandaiController.getInstance().getImageLoader();
    private CartDatabaseHandler cartDatabaseHandler;
    private QuantityUpdateListener quantityUpdateListener;

    public MyCartAdapter(Context context, ArrayList<Cart> carts, QuantityUpdateListener quantityUpdateListener) {
        this.context = context;
        this.carts = carts;
        this.quantityUpdateListener = quantityUpdateListener;
        cartDatabaseHandler = new CartDatabaseHandler(context);
        mLayoutInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount() {
        return carts.size();
    }

    @Override
    public Object getItem(int position) {
        return carts.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        ViewHolder holder = null;
        if (convertView == null) {
            holder = new ViewHolder();
            convertView = mLayoutInflater.inflate(R.layout.cart_row_layout, parent, false);
            convertView.setTag(holder);
            holder.txt_pname = convertView.findViewById(R.id.txt_pname);
            holder.txt_price = convertView.findViewById(R.id.txt_price);
            holder.txt_total = convertView.findViewById(R.id.txt_total);
            holder.img_prod = convertView.findViewById(R.id.img_prod);
            holder.btn_remove_item = convertView.findViewById(R.id.btn_remove_item);
            holder.txt_change_qty = convertView.findViewById(R.id.txt_change_qty);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }

        holder.txt_pname.setText(carts.get(position).getPname());
        holder.txt_price.setText("₹ " + Float.valueOf(carts.get(position).getPrice()) + "/" + carts.get(position).getUnit());
        holder.img_prod.setDefaultImageResId(R.mipmap.ic_launcher);
        holder.txt_total.setText(carts.get(position).getPrice() + " × " + carts.get(position).getQty() + " = ₹ " + Double.valueOf(Double.valueOf(carts.get(position).getPrice())) * Integer.valueOf(carts.get(position).getQty()));
        try {
            if (!carts.get(position).getUrl().isEmpty())
                holder.img_prod.setImageUrl(carts.get(position).getUrl().replace("http:milkbar.scrimatec.com/and_admin2/", "http:/milkbar.scrimatec.com/and_admin2/"), imageLoader);
        } catch (Exception e) {
            Toast.makeText(context, "error while loading image", Toast.LENGTH_SHORT).show();
            e.printStackTrace();
        }
        holder.btn_remove_item.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(context, "Product removed from Basket", Toast.LENGTH_SHORT).show();
                cartDatabaseHandler.removeProduct(String.valueOf(carts.get(position).getId()));
                carts.clear();
                double total = 0;
                carts = cartDatabaseHandler.getAllProducts();
                for (int i = 0; i < carts.size(); i++) {
                    total = total + (Double.valueOf(carts.get(i).getPrice()) * Integer.valueOf(carts.get(i).getQty()));
                }
                if (carts.size() == 0) {
                    total = 0;
                }
                MyCartActivity.updateTotalPrice(String.valueOf(total));
                notifyDataSetChanged();
            }
        });
        holder.txt_change_qty.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final Dialog dialog = new Dialog(context);
                dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
                dialog.setCancelable(true);
                dialog.setContentView(R.layout.change_quantity_dialog_layout);
                dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));

                ImageView img_minus = dialog.findViewById(R.id.img_minus);
                ImageView img_add = dialog.findViewById(R.id.img_add);
                final TextView txt_quantity = dialog.findViewById(R.id.txt_quantity);
                txt_quantity.setText(carts.get(position).getQty());
                Button btn_save = dialog.findViewById(R.id.btn_save);
                btn_save.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Toast.makeText(context, "Okay", Toast.LENGTH_SHORT).show();
                        Cart cart = new Cart(carts.get(position).getId(), txt_quantity.getText().toString().trim(), carts.get(position).getPrice());
                        cartDatabaseHandler.updateProduct(cart);
                        carts.clear();
                        carts.addAll(cartDatabaseHandler.getAllProducts());
                        notifyDataSetChanged();
                        quantityUpdateListener.onQuantityChanged();
                        dialog.cancel();
                    }
                });
                img_add.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        if (Integer.parseInt(txt_quantity.getText().toString().trim()) >= 99) {

                        } else {
                            txt_quantity.setText(String.valueOf((Integer.valueOf(txt_quantity.getText().toString().trim()) + 1)));
                        }
                        Log.d("TAGG", "add clicked: " + txt_quantity.getText().toString().trim());
                    }
                });
                img_minus.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        if (Integer.parseInt(txt_quantity.getText().toString().trim()) == 1) {

                        } else {
                            txt_quantity.setText(String.valueOf((Integer.valueOf(txt_quantity.getText().toString().trim()) - 1)));
                        }
                        Log.d("TAGG", "minus clicked: " + txt_quantity.getText().toString().trim());
                    }
                });
                dialog.show();
            }
        });
        return convertView;
    }

    private class ViewHolder {
        private TextView txt_pname, txt_price, txt_total, txt_change_qty;
        private ImageView btn_remove_item;
        private NetworkImageView img_prod;
    }
}