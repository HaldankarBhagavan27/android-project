package www.scrimatec.cafe18.utils;

import android.content.Context;
import android.content.SharedPreferences;

public class AppPreference {

    public static final String APP_NAME_KEY = "konkan";
    public static final String USERID_KEY = "userid";
    public static final String NAME_KEY = "name";
    public static final String EMAIL_KEY = "email";
    public static final String MOB_NO_KEY = "mobno";
    public static final String ADDRESS_KEY = "address";
    private static final String TOKEN_KEY = "token";

    public SharedPreferences preferences;
    private SharedPreferences.Editor editor;

    private String userId;
    private String name;
    private String email;
    private String mobile;
    private String address;
    private String token;

    public AppPreference(Context context) {
        preferences = context.getSharedPreferences(APP_NAME_KEY, Context.MODE_PRIVATE);
        editor = preferences.edit();
    }

    public void setUserId(String userId) {
        this.userId = userId;
        editor.putString(USERID_KEY, this.userId);
        editor.commit();
    }

    public String getUserId() {
        return preferences.getString(USERID_KEY, "0");
    }

    public void setName(String name) {
        this.name = name;
        editor.putString(NAME_KEY, this.name);
        editor.commit();
    }

    public String getName() {
        return preferences.getString(NAME_KEY, "");
    }

    public void setEmail(String email) {
        this.email = email;
        editor.putString(EMAIL_KEY, this.email);
        editor.commit();
    }

    public String getEmail() {
        return preferences.getString(EMAIL_KEY, "");
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
        editor.putString(MOB_NO_KEY, this.mobile);
        editor.commit();
    }

    public String getMobile() {
        return preferences.getString(MOB_NO_KEY, "");
    }

    public String getAddress() {
        return preferences.getString(ADDRESS_KEY, "");
    }

    public void setAddress(String address) {
        this.address = address;
        editor.putString(ADDRESS_KEY, this.address);
        editor.commit();
    }

    public String getTokenKey() {
        return preferences.getString(TOKEN_KEY, null);
    }

    public void setTokenKey(String token) {
        this.token = token;
        editor.putString(TOKEN_KEY, this.token);
        editor.commit();
    }
}
