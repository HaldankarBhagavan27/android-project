package www.scrimatec.cafe18.orders_details;

import android.content.Context;

import com.android.volley.Request;
import com.google.gson.Gson;
import www.scrimatec.cafe18.network.NetworkManager;
import www.scrimatec.cafe18.network.NetworkResponseListener;

import org.json.JSONException;
import org.json.JSONObject;

public class OrderDetailsManager implements NetworkResponseListener {
    private static OrderDetailsManager mInstance;
    private OrderDetailsResponseListener mOrderDetailsResponseListener;
    private OrderDetailsResponsePojo mOrderDetailsResponsePojo;

    public static OrderDetailsManager getInstance() {
        return (mInstance == null) ? mInstance = new OrderDetailsManager() : mInstance;
    }

    public void registerOrderDetailsListener(OrderDetailsResponseListener orderDetailsResponseListener) {
        NetworkManager.getInstance().registerListener(this);
        mOrderDetailsResponseListener = orderDetailsResponseListener;
    }

    public void deregisterOrderDetailsListener() {
        NetworkManager.getInstance().deRegisterListener(this);
        mOrderDetailsResponseListener = null;
    }

    public void sendOrderDetailsRequest(Context context, String invoice_num) {
        Gson gson = new Gson();
        OrderDetailsRequestPojo orderDetailsRequestPojo = new OrderDetailsRequestPojo(invoice_num);
        JSONObject jsonObject = null;
        try {
            jsonObject = new JSONObject(gson.toJson(orderDetailsRequestPojo));
        } catch (JSONException e) {
            e.printStackTrace();
        }
        NetworkManager.getInstance().sendJsonObjectRequest(context, Request.Method.POST, NetworkManager.getInstance().getOrderDetailsUrl(), jsonObject, NetworkManager.RequestType.ORDER_DETAILS);
    }

    public OrderDetailsResponsePojo getmOrderDetailsResponsePojo(){
        return mOrderDetailsResponsePojo;
    }

    @Override
    public void onNetworkResponseReceived(String response, NetworkManager.RequestType requestType) {
        Gson gson = new Gson();
        if (requestType == NetworkManager.RequestType.ORDER_DETAILS) {
            if (mOrderDetailsResponseListener == null)
                return;
            mOrderDetailsResponsePojo = gson.fromJson(response, OrderDetailsResponsePojo.class);
            if (mOrderDetailsResponsePojo.getOrder_details().length > 0) {
                mOrderDetailsResponseListener.onOrderDetailsResponseReceived();
            } else {
                mOrderDetailsResponseListener.onOrderDetailsResponseFailed();
            }
        }
    }

    @Override
    public void onNetworkResponseFailed(NetworkManager.RequestType requestType) {
        if (requestType == NetworkManager.RequestType.ORDER_DETAILS) {
            mOrderDetailsResponseListener.onOrderDetailsResponseTimeout();
        }
    }
}