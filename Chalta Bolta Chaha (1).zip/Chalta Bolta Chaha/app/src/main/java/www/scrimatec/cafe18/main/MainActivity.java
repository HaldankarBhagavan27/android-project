package www.scrimatec.cafe18.main;

import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.github.ybq.android.spinkit.SpinKitView;
import www.scrimatec.cafe18.R;
import www.scrimatec.cafe18.feedback.FeedbackActivity;
import www.scrimatec.cafe18.help.HelpandContactActivity;
import www.scrimatec.cafe18.login.LoginActivity;
import www.scrimatec.cafe18.mycart.CartDatabaseHandler;
import www.scrimatec.cafe18.mycart.MyCartActivity;
import www.scrimatec.cafe18.order_list.OrderListActivity;
import www.scrimatec.cafe18.profile.UserProfileActivity;
import www.scrimatec.cafe18.search.SearchActivity;
import www.scrimatec.cafe18.utils.AppPreference;
import www.scrimatec.cafe18.utils.NavDrawerItem;
import www.scrimatec.cafe18.utils.NavDrawerListAdapter;

import java.util.ArrayList;

//import uk.co.chrisjenx.calligraphy.CalligraphyContextWrapper;

public class MainActivity extends AppCompatActivity implements CategoryResponseListener, View.OnClickListener {
    private DrawerLayout mDrawerLayout;
    private ListView mDrawerList;
    private ArrayList<NavDrawerItem> mDrawerArrayList;
    private NavDrawerListAdapter mNavDrawerListAdapter;
    private ActionBarDrawerToggle mDrawerToggle;
    private RelativeLayout navigationLayout;
    private GridLayoutManager lLayout;
    private Toolbar toolbar;
    private ImageView img_back_arrow,img_search;
    private TextView txt_username, txt_title, txt_cart_bubble;
    private RelativeLayout lay_toolbar_cart;
    private CartDatabaseHandler cartDatabaseHandler;
    private AppPreference appPreference;
    private RecyclerView rView;
    private SpinKitView main_loader;
    private CategoryAdapter categoryAdapter;
    private LinearLayout profile_layout;
    private Dialog dialog;
    private boolean isDrawerOpen = false;
    public static Cat_list[] cat_list;

//    @Override
//    protected void attachBaseContext(Context newBase) {
//        super.attachBaseContext(CalligraphyContextWrapper.wrap(newBase));
//    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Log.d("TAGG", "main act");

        appPreference = new AppPreference(MainActivity.this);
        profile_layout = findViewById(R.id.profile_layout);
        profile_layout.setOnClickListener(this);
        mDrawerLayout = findViewById(R.id.drawer_layout);
        mDrawerList = findViewById(R.id.left_drawer_list);
        navigationLayout = findViewById(R.id.navListLayout);
        toolbar = findViewById(R.id.app_bar);
        img_search = toolbar.findViewById(R.id.img_search);
        img_search.setVisibility(View.VISIBLE);
        img_back_arrow = toolbar.findViewById(R.id.img_back_arrow);
        img_back_arrow.setVisibility(View.INVISIBLE);
        txt_title = toolbar.findViewById(R.id.txt_title);
        txt_title.setGravity(Gravity.CENTER_HORIZONTAL | Gravity.CENTER_VERTICAL);
        txt_title.setTextSize(TypedValue.COMPLEX_UNIT_PX, getResources().getDimension(R.dimen.header));
        txt_title.setText("Welcome    ");
        lay_toolbar_cart = toolbar.findViewById(R.id.lay_toolbar_cart);
        lay_toolbar_cart.setOnClickListener(this);
        txt_cart_bubble = toolbar.findViewById(R.id.txt_cart_bubble);
        cartDatabaseHandler = new CartDatabaseHandler(MainActivity.this);
        txt_username = findViewById(R.id.txt_username);

        mDrawerToggle = new ActionBarDrawerToggle(this, mDrawerLayout, toolbar, R.string.openDrawer, R.string.closeDrawer) {
            @Override
            public void onDrawerOpened(View drawerView) {
                super.onDrawerOpened(drawerView);
            }

            @Override
            public void onDrawerClosed(View drawerView) {
                super.onDrawerClosed(drawerView);
            }
        };
        mDrawerLayout.setDrawerListener(mDrawerToggle);
        mDrawerToggle.syncState();
        mDrawerArrayList = new ArrayList<NavDrawerItem>();
        mDrawerToggle = new ActionBarDrawerToggle(this, mDrawerLayout, toolbar, R.string.app_name, R.string.app_name) {
            public void onDrawerClosed(View view) {
                invalidateOptionsMenu();
                isDrawerOpen = false;
            }

            public void onDrawerOpened(View drawerView) {
                invalidateOptionsMenu();
                isDrawerOpen = true;
            }
        };
        mDrawerLayout.setDrawerListener(mDrawerToggle);
        mDrawerList.setOnItemClickListener(new DrawerItemClickListener());

        lLayout = new GridLayoutManager(MainActivity.this, 2);

        rView = findViewById(R.id.rv_cat);
        main_loader = findViewById(R.id.main_loader);

        CategoryManager.getInstance().registerCatListener(this);
        CategoryManager.getInstance().sendCatRequest(MainActivity.this);
        rView.setVisibility(View.GONE);
        main_loader.setVisibility(View.VISIBLE);

        img_search.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MainActivity.this, SearchActivity.class);
                startActivity(i);
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        mDrawerToggle.setDrawerIndicatorEnabled(true);
        if (!appPreference.getUserId().equals("0")) {
            txt_username.setText(appPreference.getName());
        }else {
            txt_username.setText("Welcome!!!");
        }
        if (cartDatabaseHandler.getCartCount() == 0) {
            txt_cart_bubble.setVisibility(View.GONE);
        } else {
            txt_cart_bubble.setVisibility(View.VISIBLE);
            txt_cart_bubble.setText(String.valueOf(cartDatabaseHandler.getCartCount()));
        }
        setDrawer();
    }


    @Override
    public void onCategoryResponseReceived() {
        rView.setVisibility(View.VISIBLE);
        main_loader.setVisibility(View.GONE);
        rView.setHasFixedSize(true);
        rView.setLayoutManager(lLayout);
        categoryAdapter = new CategoryAdapter(MainActivity.this, CategoryManager.getInstance().getmCategoryResponsePojo().getCat_list());
        rView.setAdapter(categoryAdapter);
        cat_list = CategoryManager.getInstance().getmCategoryResponsePojo().getCat_list();
    }

    @Override
    public void onCategoryResponseFailed() {
        rView.setVisibility(View.GONE);
        main_loader.setVisibility(View.GONE);
        Toast.makeText(MainActivity.this, R.string.something_went_wrong, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onCategoryResponseTimeout() {
        rView.setVisibility(View.GONE);
        main_loader.setVisibility(View.GONE);
        Toast.makeText(MainActivity.this, R.string.internet_connection_error, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.profile_layout) {
            if (!appPreference.getUserId().equals("0")) {
                Intent intent = new Intent(MainActivity.this, UserProfileActivity.class);
                startActivity(intent);
                mDrawerLayout.closeDrawers();
            } else {
                Toast.makeText(this, "Please login to see your profile", Toast.LENGTH_SHORT).show();
                mDrawerLayout.closeDrawers();
            }
        } else if (v.getId() == R.id.lay_toolbar_cart) {
            if (cartDatabaseHandler.getCartCount() > 0) {
                Intent intent = new Intent(MainActivity.this, MyCartActivity.class);
                startActivity(intent);
            } else {
                Toast.makeText(this, "Nothing in Basket", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private class DrawerItemClickListener implements AdapterView.OnItemClickListener {
        @Override
        public void onItemClick(AdapterView<?> parent, View view, final int position, long id) {
            DrawerClickListener(position);
        }
    }

    private void DrawerClickListener(int position) {
        Intent intent;
        if (appPreference.getUserId().equals("0")) {
            switch (position) {
                case 0:
                    intent = new Intent(MainActivity.this, LoginActivity.class);
                    startActivity(intent);
                    mDrawerLayout.closeDrawers();
                    break;
                case 1:
                    intent = new Intent(MainActivity.this, HelpandContactActivity.class);
                    startActivity(intent);
                    mDrawerLayout.closeDrawers();
                    break;
                case 2:
                    Uri uri = Uri.parse("https://play.google.com/store/apps/details?id=www.muthabrothers.extremesportswear");
                    Intent reviewIntent = new Intent(Intent.ACTION_VIEW, uri);
                    startActivity(reviewIntent);
                    mDrawerLayout.closeDrawers();
                    break;
                case 3:
                    try {
                        Intent sharingIntent = new Intent(Intent.ACTION_SEND);
                        sharingIntent.setType("text/plain");
                        String shareBody = "Hey check out this app to buy Sports Wear Outfits. Download and Install: https://play.google.com/store/apps/details?id=www.muthabrothers.extremesportswear";
                        sharingIntent.putExtra(Intent.EXTRA_SUBJECT, "Download Extreme Sportswear");
                        sharingIntent.putExtra(Intent.EXTRA_TEXT, shareBody);
                        startActivity(Intent.createChooser(sharingIntent, "Share Extreme Sportswear via"));
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    mDrawerLayout.closeDrawers();
                    break;
            }
        } else {
            switch (position) {
                case 0:
                    intent = new Intent(this, MyCartActivity.class);
                    startActivityForResult(intent, 1);
                    mDrawerLayout.closeDrawers();
                    break;
                case 1:
                    intent = new Intent(this, OrderListActivity.class);
                    startActivityForResult(intent, 1);
                    mDrawerLayout.closeDrawers();
                    break;
                case 2:
                    intent = new Intent(MainActivity.this, HelpandContactActivity.class);
                    startActivity(intent);
                    mDrawerLayout.closeDrawers();
                    break;
                case 3:
                    intent = new Intent(this, FeedbackActivity.class);
                    startActivityForResult(intent, 1);
                    mDrawerLayout.closeDrawers();
                    break;
                case 4:
                    Uri uri = Uri.parse("https://play.google.com/store/apps/details?id=www.muthabrothers.extremesportswear");
                    Intent reviewIntent = new Intent(Intent.ACTION_VIEW, uri);
                    startActivity(reviewIntent);
                    mDrawerLayout.closeDrawers();
                    break;
                case 5:
                    Intent sharingIntent = new Intent(Intent.ACTION_SEND);
                    sharingIntent.setType("text/plain");
                    String shareBody = "Hey check out this app to buy Sports Wear Outfits. Download and Install: https://play.google.com/store/apps/details?id=www.muthabrothers.extremesportswear";
                    sharingIntent.putExtra(Intent.EXTRA_SUBJECT, "Download Extreme Sportswear");
                    sharingIntent.putExtra(Intent.EXTRA_TEXT, shareBody);
                    startActivity(Intent.createChooser(sharingIntent, "Share Products via"));
                    break;
                case 6:
                    try {
                        logoutAlert();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    mDrawerLayout.closeDrawers();
                    break;
                case 7:
                    logoutAlert();
                    mDrawerLayout.closeDrawers();
                    break;
            }
        }

    }

    private void setDrawer() {
        mDrawerArrayList.clear();
        if (appPreference.getUserId().equals("0")) {
            mDrawerArrayList.add(new NavDrawerItem(R.drawable.login, "Login"));
            mDrawerArrayList.add(new NavDrawerItem(R.drawable.info, "Help & Contact"));
            mDrawerArrayList.add(new NavDrawerItem(R.drawable.rate, "Rate The App"));
            mDrawerArrayList.add(new NavDrawerItem(R.drawable.share, "Share"));
        } else {
            mDrawerArrayList.add(new NavDrawerItem(R.drawable.cart, "My Basket"));
            mDrawerArrayList.add(new NavDrawerItem(R.drawable.orders, "My Orders"));
//            mDrawerArrayList.add(new NavDrawerItem(R.drawable.orders, "Order On Phone"));
            mDrawerArrayList.add(new NavDrawerItem(R.drawable.info, "Help & Contact"));
            mDrawerArrayList.add(new NavDrawerItem(R.drawable.feedback, "Feedback"));
            mDrawerArrayList.add(new NavDrawerItem(R.drawable.rate, "Rate The App"));
            mDrawerArrayList.add(new NavDrawerItem(R.drawable.share, "Share"));
            mDrawerArrayList.add(new NavDrawerItem(R.drawable.logout, "Log Out"));
        }
        mNavDrawerListAdapter = new NavDrawerListAdapter(this, mDrawerArrayList);
        mDrawerList.setAdapter(mNavDrawerListAdapter);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        mDrawerLayout.closeDrawers();
    }

    @Override
    public void onBackPressed() {
        if (isDrawerOpen) {
            mDrawerLayout.closeDrawers();
        } else {
            finishAffinity();
        }
    }

    private void logoutAlert() {
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);
        alertDialogBuilder.setMessage("Are you sure, you want to logout?");
        alertDialogBuilder.setPositiveButton("Yes",
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface arg0, int arg1) {
                        finishAffinity();
                        appPreference.setUserId("0");
                    }
                });

        alertDialogBuilder.setNegativeButton("No",
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });

        AlertDialog alertDialog = alertDialogBuilder.create();
        alertDialog.show();
    }
}

/*prodlist
proddetails
orderdetails */