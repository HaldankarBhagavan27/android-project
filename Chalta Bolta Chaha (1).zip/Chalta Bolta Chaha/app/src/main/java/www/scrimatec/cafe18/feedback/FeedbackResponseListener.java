package www.scrimatec.cafe18.feedback;


public interface FeedbackResponseListener {
    void onFeedbackResponseReceived();

    void onFeedbackResponseFailed();

    void onFeedbackResponseTimeout();
}
