package www.scrimatec.cafe18.product_list;

public class Arr_old_price {
    private String old_price;

    public String getOld_price() {
        return old_price;
    }

    public void setOld_price(String old_price) {
        this.old_price = old_price;
    }

    @Override
    public String toString() {
        return "ClassPojo [price = " + old_price + "]";
    }
}
