package www.scrimatec.cafe18.order_list;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import www.scrimatec.cafe18.R;

public class OrderListAdapter extends BaseAdapter {
    private Context context;
    private Ord_list[] ord_list;
    private LayoutInflater mLayoutInflater;

    public OrderListAdapter(Context context, Ord_list[] ord_list) {
        this.context = context;
        this.ord_list = ord_list;
        mLayoutInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount() {
        return ord_list.length;
    }

    @Override
    public Object getItem(int position) {
        return ord_list[position];
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        ViewHolder holder = null;
        if (convertView == null) {
            holder = new ViewHolder();
            convertView = mLayoutInflater.inflate(R.layout.order_row_layout, parent, false);
            convertView.setTag(holder);
            holder.txt_inv_no = convertView.findViewById(R.id.txt_inv_no);
            holder.txt_date = convertView.findViewById(R.id.txt_date);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }

        holder.txt_inv_no.setText("Invoice No.: " + ord_list[position].getInvoice_num());
        holder.txt_date.setText("Delivery Date : " + ord_list[position].getDate());
        return convertView;
    }

    private class ViewHolder {
        private TextView txt_inv_no, txt_date;
    }
}