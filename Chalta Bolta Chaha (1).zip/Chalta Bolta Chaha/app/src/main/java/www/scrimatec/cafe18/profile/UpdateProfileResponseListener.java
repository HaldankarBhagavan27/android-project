package www.scrimatec.cafe18.profile;

public interface UpdateProfileResponseListener {
    void onUpdateProfileResponseReceived();

    void onUpdateProfileResponseFailed();

    void onUpdateProfileTimeoutReceived();
}
