package www.scrimatec.cafe18.product_details;

import www.scrimatec.cafe18.product_list.Arr_price;
import www.scrimatec.cafe18.product_list.Arr_quant;
import www.scrimatec.cafe18.product_list.Arr_unit;

public class Prod_details {
    private Arr_unit[] arr_unit;

    private Arr_quant[] arr_quant;

    private String img_url;

    private String name;

    private String details;

    private String id;

    private Arr_price[] arr_price;

    private String mar_name;

    public Arr_unit[] getArr_unit() {
        return arr_unit;
    }

    public void setArr_unit(Arr_unit[] arr_unit) {
        this.arr_unit = arr_unit;
    }

    public Arr_quant[] getArr_quant() {
        return arr_quant;
    }

    public void setArr_quant(Arr_quant[] arr_quant) {
        this.arr_quant = arr_quant;
    }

    public String getImg_url() {
        return img_url;
    }

    public void setImg_url(String img_url) {
        this.img_url = img_url;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDetails() {
        return details;
    }

    public void setDetails(String details) {
        this.details = details;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Arr_price[] getArr_price() {
        return arr_price;
    }

    public void setArr_price(Arr_price[] arr_price) {
        this.arr_price = arr_price;
    }

    public String getMar_name() {
        return mar_name;
    }

    public void setMar_name(String mar_name) {
        this.mar_name = mar_name;
    }

    @Override
    public String toString() {
        return "ClassPojo [arr_unit = " + arr_unit + ", arr_quant = " + arr_quant + ", img_url = " + img_url + ", name = " + name + ", details = " + details + ", id = " + id + ", arr_price = " + arr_price + ", mar_name = " + mar_name + "]";
    }
}
