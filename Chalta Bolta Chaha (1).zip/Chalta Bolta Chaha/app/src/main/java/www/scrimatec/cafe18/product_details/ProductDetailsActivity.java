package www.scrimatec.cafe18.product_details;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.toolbox.ImageLoader;
import com.android.volley.toolbox.NetworkImageView;
import com.github.ybq.android.spinkit.SpinKitView;
import www.scrimatec.cafe18.R;
import www.scrimatec.cafe18.mycart.Cart;
import www.scrimatec.cafe18.mycart.CartDatabaseHandler;
import www.scrimatec.cafe18.mycart.MyCartActivity;
import www.scrimatec.cafe18.utils.MandaiController;

import java.util.ArrayList;
import java.util.List;

//import uk.co.chrisjenx.calligraphy.CalligraphyContextWrapper;

public class ProductDetailsActivity extends AppCompatActivity implements ProductDetailsResponseListener, View.OnClickListener {
    private ScrollView scroll_prod_details;
    private SpinKitView prod_details_loader;
    private NetworkImageView img_prod;
    private TextView txt_prod_name, txt_initial_price, txt_price, txt_des;
    private ImageView img_minus, img_add;
    private TextView edt_quantity;
    private Button btn_add_to_cart;
    private String productId, name;
    private Spinner spinner_unit;
    private CartDatabaseHandler cartDatabaseHandler;
    private boolean cartFlag = false;
    private List<Cart> carts;
    private String qty;
    private Toolbar toolbar;
    private ImageView img_back_arrow;
    private String sPrice = "0", sUnit = "";
    private TextView txt_title, txt_cart_bubble;
    private RelativeLayout lay_toolbar_cart;
    private boolean firstLoadFlag = true;

//    @Override
//    protected void attachBaseContext(Context newBase) {
//        super.attachBaseContext(CalligraphyContextWrapper.wrap(newBase));
//    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_product_details);

        productId = getIntent().getStringExtra("productId");
        name = getIntent().getStringExtra("name");
        cartDatabaseHandler = new CartDatabaseHandler(ProductDetailsActivity.this);
        scroll_prod_details = findViewById(R.id.scroll_prod_details);
        prod_details_loader = findViewById(R.id.prod_details_loader);
        img_prod = findViewById(R.id.img_prod);
        txt_prod_name = findViewById(R.id.txt_prod_name);
        txt_initial_price = findViewById(R.id.txt_initial_price);
        txt_price = findViewById(R.id.txt_price);
        txt_des = findViewById(R.id.txt_des);
        img_minus = findViewById(R.id.img_minus);
        img_minus.setOnClickListener(this);
        img_add = findViewById(R.id.img_add);
        img_add.setOnClickListener(this);
        spinner_unit = findViewById(R.id.spinner_unit);
        edt_quantity = findViewById(R.id.edt_quantity);
        btn_add_to_cart = findViewById(R.id.btn_add_to_cart);
        toolbar = findViewById(R.id.app_bar);
        img_back_arrow = toolbar.findViewById(R.id.img_back_arrow);
        img_back_arrow.setVisibility(View.VISIBLE);
        img_back_arrow.setOnClickListener(this);
        txt_title = toolbar.findViewById(R.id.txt_title);
        txt_title.setText(name);
        lay_toolbar_cart = toolbar.findViewById(R.id.lay_toolbar_cart);
        lay_toolbar_cart.setOnClickListener(this);
        txt_cart_bubble = toolbar.findViewById(R.id.txt_cart_bubble);
        btn_add_to_cart.setOnClickListener(this);
        qty = "1";
        edt_quantity.setText(qty);
        /*edt_quantity.addTextChangedListener(new TextWatcher() {

            @Override
            public void afterTextChanged(Editable s) {
            }

            @Override
            public void beforeTextChanged(CharSequence s, int start,
                                          int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (s.length() != 0) {
                    qty = edt_quantity.getText().toString();
                    qty = String.valueOf(Integer.valueOf(qty));
                    txt_initial_price.setText("Per " + ProductDetailsManager.getInstance().getmProductDetailsResponsePojo().getProd_details()[0].getArr_unit().split("#")[1] + " " + ProductDetailsManager.getInstance().getmProductDetailsResponsePojo().getProd_details()[0].getUnit().split("#")[0] + " Price : ₹ " + ProductDetailsManager.getInstance().getmProductDetailsResponsePojo().getProd_details()[0].getPrice());
                    if (Integer.valueOf(qty) == 1)
                        txt_price.setText("Total Price : ₹ " + String.valueOf((Integer.valueOf(ProductDetailsManager.getInstance().getmProductDetailsResponsePojo().getProd_details()[0].getPrice()) * Integer.valueOf(qty))) + " (" + qty + " " + ProductDetailsManager.getInstance().getmProductDetailsResponsePojo().getProd_details()[0].getUnit().split("#")[0] + ")");
                    else
                        txt_price.setText("Total Price : ₹ " + String.valueOf((Integer.valueOf(ProductDetailsManager.getInstance().getmProductDetailsResponsePojo().getProd_details()[0].getPrice()) * Integer.valueOf(qty))) + " (" + qty + " " + ProductDetailsManager.getInstance().getmProductDetailsResponsePojo().getProd_details()[0].getUnit().split("#")[0] + "s)");
                }
            }
        });*/
        ProductDetailsManager.getInstance().registerProductDetailsListener(this);
    }

    @Override
    protected void onResume() {
        super.onResume();
        ProductDetailsManager.getInstance().sendProductDetailsRequest(ProductDetailsActivity.this, productId);
        scroll_prod_details.setVisibility(View.GONE);
        btn_add_to_cart.setVisibility(View.GONE);
        prod_details_loader.setVisibility(View.VISIBLE);
        carts = new ArrayList<>();
        carts = cartDatabaseHandler.getAllProducts();
        if (firstLoadFlag != true) {
            btn_add_to_cart.setText("Add To Basket");
            cartFlag = false;
            for (int i = 0; i < carts.size(); i++) {
                if (carts.get(i).getProdId().equals(ProductDetailsManager.getInstance().getmProductDetailsResponsePojo().getProd_details()[0].getId())) {
                    btn_add_to_cart.setText("See Basket");
                    cartFlag = true;
                    break;
                } else {
                    cartFlag = false;
                    btn_add_to_cart.setText("Add To Basket");
                }
            }
        }
        if (cartDatabaseHandler.getCartCount() == 0)
            txt_cart_bubble.setVisibility(View.GONE);
        else {
            txt_cart_bubble.setVisibility(View.VISIBLE);
            txt_cart_bubble.setText(String.valueOf(cartDatabaseHandler.getCartCount()));
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        firstLoadFlag = false;
    }

    @Override
    public void onProductDetailsResponseReceived() {
        scroll_prod_details.setVisibility(View.VISIBLE);
        btn_add_to_cart.setVisibility(View.VISIBLE);
        prod_details_loader.setVisibility(View.GONE);
        for (int i = 0; i < carts.size(); i++) {
            if (carts.get(i).getProdId().equals(ProductDetailsManager.getInstance().getmProductDetailsResponsePojo().getProd_details()[0].getId())) {
                btn_add_to_cart.setText("Show Basket");
                cartFlag = true;
                break;
            } else {
                cartFlag = false;
                btn_add_to_cart.setText("Add To Basket");
            }
        }
        ImageLoader imageLoader = MandaiController.getInstance().getImageLoader();
        try {
            if (!ProductDetailsManager.getInstance().getmProductDetailsResponsePojo().getProd_details()[0].getImg_url().isEmpty())
                img_prod.setImageUrl(ProductDetailsManager.getInstance().getmProductDetailsResponsePojo().getProd_details()[0].getImg_url().replace("http:operandtechnologies.com/mutha_bros", "https://muthabrothers.com/and_admin"), imageLoader);
        } catch (Exception e) {
            Toast.makeText(ProductDetailsActivity.this, "error while loading image", Toast.LENGTH_SHORT).show();
            e.printStackTrace();
        }
        ArrayList<String> units = new ArrayList<>();
        for (int i = 0; i < ProductDetailsManager.getInstance().getmProductDetailsResponsePojo().getProd_details()[0].getArr_unit().length; i++)
            units.add(ProductDetailsManager.getInstance().getmProductDetailsResponsePojo().getProd_details()[0].getArr_unit()[i].getUnit());
        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(ProductDetailsActivity.this, android.R.layout.simple_spinner_item, units);
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner_unit.setAdapter(dataAdapter);
        spinner_unit.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                txt_initial_price.setText(" Price per " + ProductDetailsManager.getInstance().getmProductDetailsResponsePojo().getProd_details()[0].getArr_unit()[i].getUnit() + " " + ProductDetailsManager.getInstance().getmProductDetailsResponsePojo().getProd_details()[0].getArr_quant()[i].getQuant() + ": ₹ " + ProductDetailsManager.getInstance().getmProductDetailsResponsePojo().getProd_details()[0].getArr_price()[i].getPrice());
                txt_price.setText("Total Price : ₹ " + Double.valueOf(ProductDetailsManager.getInstance().getmProductDetailsResponsePojo().getProd_details()[0].getArr_price()[i].getPrice()).intValue() * Integer.valueOf(qty) + " (" + qty + " " + ProductDetailsManager.getInstance().getmProductDetailsResponsePojo().getProd_details()[0].getArr_unit()[i].getUnit() + ")");
                sUnit = ProductDetailsManager.getInstance().getmProductDetailsResponsePojo().getProd_details()[0].getArr_unit()[i].getUnit();
                sPrice = ProductDetailsManager.getInstance().getmProductDetailsResponsePojo().getProd_details()[0].getArr_price()[i].getPrice();
                edt_quantity.setText("1");
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
        txt_prod_name.setText(ProductDetailsManager.getInstance().getmProductDetailsResponsePojo().getProd_details()[0].getName());
        txt_des.setText(ProductDetailsManager.getInstance().getmProductDetailsResponsePojo().getProd_details()[0].getDetails());
    }

    @Override
    public void onProductDetailsResponseFailed() {
        scroll_prod_details.setVisibility(View.GONE);
        btn_add_to_cart.setVisibility(View.GONE);
        prod_details_loader.setVisibility(View.GONE);
    }

    @Override
    public void onProductDetailsResponseTimeout() {
        scroll_prod_details.setVisibility(View.GONE);
        btn_add_to_cart.setVisibility(View.GONE);
        prod_details_loader.setVisibility(View.GONE);
    }

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.btn_add_to_cart) {
            if (cartFlag == true) {
                Intent intent = new Intent(ProductDetailsActivity.this, MyCartActivity.class);
                startActivity(intent);
            } else {
                cartDatabaseHandler.addToCart(new Cart(ProductDetailsManager.getInstance().getmProductDetailsResponsePojo().getProd_details()[0].getId(), ProductDetailsManager.getInstance().getmProductDetailsResponsePojo().getProd_details()[0].getName(), ProductDetailsManager.getInstance().getmProductDetailsResponsePojo().getProd_details()[0].getImg_url(), String.valueOf(Integer.valueOf(qty)), sUnit, sPrice));
                Toast.makeText(ProductDetailsActivity.this, "Product added to Basket", Toast.LENGTH_SHORT).show();
                btn_add_to_cart.setText("Show Basket");
                cartFlag = true;
                if (cartDatabaseHandler.getCartCount() == 0)
                    txt_cart_bubble.setVisibility(View.GONE);
                else {
                    txt_cart_bubble.setVisibility(View.VISIBLE);
                    txt_cart_bubble.setText(String.valueOf(cartDatabaseHandler.getCartCount()));
                }
            }
        } else if (v.getId() == R.id.img_minus) {
            if (edt_quantity.getText().toString().length() > 0) {
                qty = edt_quantity.getText().toString();
                qty = String.valueOf(Integer.valueOf(qty));
                if (Integer.valueOf(qty) == 1) {
                    Toast.makeText(ProductDetailsActivity.this, "Invalid quantity", Toast.LENGTH_SHORT).show();
                } else {
                    qty = String.valueOf((Integer.valueOf(qty) - 1));
                    edt_quantity.setText(qty);
                    txt_initial_price.setText("Per " + sUnit + " " + " Price : ₹ " + sPrice);
                    txt_price.setText("Total Price : ₹ " + Double.valueOf(sPrice) * Integer.valueOf(qty) + " (" + qty + " " + sUnit + ")");
                }
            } else {
                Toast.makeText(ProductDetailsActivity.this, "Enter quantity", Toast.LENGTH_SHORT).show();
            }
        } else if (v.getId() == R.id.img_add) {
            if (edt_quantity.getText().toString().length() > 0) {
                qty = edt_quantity.getText().toString();
                qty = String.valueOf(Integer.valueOf(qty));
                if (Integer.valueOf(qty) == 999) {
                    Toast.makeText(ProductDetailsActivity.this, "Invalid quantity", Toast.LENGTH_SHORT).show();
                } else {
                    qty = String.valueOf((Integer.valueOf(qty) + 1));
                    edt_quantity.setText(qty);
                    txt_initial_price.setText("Per " + sUnit + " " + " Price : ₹ " + sPrice);
                    txt_price.setText("Total Price : ₹ " + Double.valueOf(sPrice) * Integer.valueOf(qty) + " (" + qty + " " + sUnit + ")");
                }
            } else {
                Toast.makeText(ProductDetailsActivity.this, "Enter quantity", Toast.LENGTH_SHORT).show();
            }
        } else if (v.getId() == R.id.img_back_arrow) {
            finish();
        } else if (v.getId() == R.id.lay_toolbar_cart) {
            if (cartDatabaseHandler.getCartCount() > 0) {
                Intent intent = new Intent(ProductDetailsActivity.this, MyCartActivity.class);
                startActivity(intent);
            } else {
                Toast.makeText(this, "Nothing in Basket", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
