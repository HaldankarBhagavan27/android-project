package www.scrimatec.cafe18.order_list;

public class OrderListRequestPojo {
    String id;

    public OrderListRequestPojo(String id) {
        this.id = id;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }
}
