package www.scrimatec.cafe18.mycart;

public interface QuantityUpdateListener {
    void onQuantityChanged();
}
