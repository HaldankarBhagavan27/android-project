package www.scrimatec.cafe18.product_details;

import android.content.Context;
import android.util.Log;

import com.android.volley.Request;
import com.google.gson.Gson;
import www.scrimatec.cafe18.network.NetworkManager;
import www.scrimatec.cafe18.network.NetworkResponseListener;

import org.json.JSONException;
import org.json.JSONObject;

public class ProductDetailsManager implements NetworkResponseListener {
    private static ProductDetailsManager mInstance;
    private ProductDetailsResponseListener mProductDetailsResponseListener;
    private ProductDetailsResponsePojo mProductDetailsResponsePojo;

    public static ProductDetailsManager getInstance() {
        return (mInstance == null) ? mInstance = new ProductDetailsManager() : mInstance;
    }

    public void registerProductDetailsListener(ProductDetailsResponseListener productDetailsResponseListener) {
        NetworkManager.getInstance().registerListener(this);
        mProductDetailsResponseListener = productDetailsResponseListener;
    }

    public void deregisterProductDetailsListener() {
        NetworkManager.getInstance().deRegisterListener(this);
        mProductDetailsResponseListener = null;
    }

    public void sendProductDetailsRequest(Context context, String id) {
        Gson gson = new Gson();
        ProductDetailsRequestPojo productDetailsRequestPojo = new ProductDetailsRequestPojo(id);
        JSONObject jsonObject = null;
        try {
            jsonObject = new JSONObject(gson.toJson(productDetailsRequestPojo));
        } catch (JSONException e) {
            e.printStackTrace();
        }
        NetworkManager.getInstance().sendJsonObjectRequest(context, Request.Method.POST, NetworkManager.getInstance().getProductDetailsUrl(), jsonObject, NetworkManager.RequestType.PROD_DETAILS);
    }

    public ProductDetailsResponsePojo getmProductDetailsResponsePojo() {
        return mProductDetailsResponsePojo;
    }

    @Override
    public void onNetworkResponseReceived(String response, NetworkManager.RequestType requestType) {
        Gson gson = new Gson();
        if (requestType == NetworkManager.RequestType.PROD_DETAILS) {
            if (mProductDetailsResponseListener == null)
                return;
            Log.d("TAGG", "prod details: " + response);
            mProductDetailsResponsePojo = gson.fromJson(response, ProductDetailsResponsePojo.class);
            if (mProductDetailsResponsePojo.getProd_details().length > 0) {
                mProductDetailsResponseListener.onProductDetailsResponseReceived();
            } else {
                mProductDetailsResponseListener.onProductDetailsResponseFailed();
            }
        }
    }

    @Override
    public void onNetworkResponseFailed(NetworkManager.RequestType requestType) {
        if (requestType == NetworkManager.RequestType.PROD_LIST) {
            mProductDetailsResponseListener.onProductDetailsResponseTimeout();
        }
    }
}

