package www.scrimatec.cafe18.profile;

public class UpdateProfileRequestPojo {
    String userId;
    String fName;
    String mobile;
    String address;
    String email;

    public UpdateProfileRequestPojo(String userId, String fName, String mobile, String address, String email) {
        this.userId = userId;
        this.fName = fName;
        this.mobile = mobile;
        this.address = address;
        this.email = email;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getfName() {
        return fName;
    }

    public void setfName(String fName) {
        this.fName = fName;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
}
