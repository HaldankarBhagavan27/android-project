package www.scrimatec.cafe18.profile;

public class UpdateProfileResponsePojo {
    private String st;

    public String getSt() {
        return st;
    }

    public void setSt(String st) {
        this.st = st;
    }
}
