package www.scrimatec.cafe18.orders_details;

public interface OrderDetailsResponseListener {
    void onOrderDetailsResponseReceived();

    void onOrderDetailsResponseFailed();

    void onOrderDetailsResponseTimeout();
}
