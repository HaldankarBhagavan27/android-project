package www.scrimatec.cafe18.signup;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.TextInputLayout;
import android.support.v7.app.AppCompatActivity;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.github.ybq.android.spinkit.SpinKitView;
import www.scrimatec.cafe18.R;
import www.scrimatec.cafe18.login.LoginActivity;
import www.scrimatec.cafe18.utils.AppPreference;

//import uk.co.chrisjenx.calligraphy.CalligraphyContextWrapper;

public class SignupActivity extends AppCompatActivity implements View.OnClickListener, SignupResponseListener, OTPResponseListener {
    private TextInputLayout input_layout_email, input_layout_password, input_layout_confirm_password, input_layout_name, input_layout_mobile, input_layout_address;
    private EditText edt_email, edt_password, edt_confirm_password, edt_name, edt_mobile, edt_address, edt_otp;
    private CheckBox chk_terms;
    private Button btn_signup, btn_verify;
    private TextView txt_login;
    private String email, password, name, mobile, address, otp;
    private AppPreference appPreference;
    private ScrollView signup_layout;
    private SpinKitView signup_loader;
    private LinearLayout lay_signup, lay_otp;

//    @Override
//    protected void attachBaseContext(Context newBase) {
//        super.attachBaseContext(CalligraphyContextWrapper.wrap(newBase));
//    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);

        SignupManager.getInstance().registerSignupListener(this);
        this.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);

        View view = this.getCurrentFocus();
        if (view != null) {
            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
        }
        lay_signup = findViewById(R.id.lay_signup);
        lay_signup.setOnClickListener(this);
        lay_signup.setVisibility(View.VISIBLE);
        lay_otp = findViewById(R.id.lay_otp);
        lay_otp.setOnClickListener(this);
        lay_otp.setVisibility(View.GONE);
        input_layout_email = findViewById(R.id.input_layout_email);
        input_layout_password = findViewById(R.id.input_layout_password);
        input_layout_confirm_password = findViewById(R.id.input_layout_confirm_password);
        input_layout_name = findViewById(R.id.input_layout_name);
        input_layout_mobile = findViewById(R.id.input_layout_mobile);
        input_layout_address = findViewById(R.id.input_layout_address);
        edt_email = findViewById(R.id.edt_email);
        edt_password = findViewById(R.id.edt_password);
        edt_confirm_password = findViewById(R.id.edt_confirm_password);
        edt_name = findViewById(R.id.edt_name);
        edt_mobile = findViewById(R.id.edt_mobile);
        edt_address = findViewById(R.id.edt_address);
        edt_otp = findViewById(R.id.edt_otp);
        chk_terms = findViewById(R.id.chk_terms);
        chk_terms.setChecked(true);
        btn_signup = findViewById(R.id.btn_signup);
        btn_signup.setOnClickListener(this);
        btn_verify = findViewById(R.id.btn_verify);
        btn_verify.setOnClickListener(this);
        txt_login = findViewById(R.id.txt_login);
        txt_login.setOnClickListener(this);
        appPreference = new AppPreference(SignupActivity.this);
        signup_layout = findViewById(R.id.signup_layout);
        signup_loader = findViewById(R.id.signup_loader);
        edt_email.addTextChangedListener(new MyTextWatcher(edt_email));
        edt_password.addTextChangedListener(new MyTextWatcher(edt_password));
        edt_confirm_password.addTextChangedListener(new MyTextWatcher(edt_confirm_password));
        edt_name.addTextChangedListener(new MyTextWatcher(edt_name));
        edt_address.addTextChangedListener(new MyTextWatcher(edt_address));
        edt_mobile.addTextChangedListener(new MyTextWatcher(edt_mobile));
        edt_email.addTextChangedListener(new MyTextWatcher(edt_email));
        SignupManager.getInstance().registerOTPListener(this);
    }

    private void submitSignUp() {
        View view = this.getCurrentFocus();
        if (view != null) {
            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
        }
        if (!validateEmail()) {
            return;
        }
        if (!validatePassword()) {
            return;
        }
        if (!validateConfirmPassword()) {
            return;
        }
        if (!validateName()) {
            return;
        }
        if (!validateMobile()) {
            return;
        }
        email = edt_email.getText().toString().trim();
        password = edt_password.getText().toString().trim();
        name = edt_name.getText().toString().trim();
        address = edt_address.getText().toString().trim();
        mobile = edt_mobile.getText().toString().trim();
        //SignupManager.getInstance().sendSignupRequest(SignupActivity.this, name, email, mobile, password, address, appPreference.getTokenKey());
        SignupManager.getInstance().sendOTPRequest(SignupActivity.this, mobile);
        signup_layout.setVisibility(View.GONE);
        signup_loader.setVisibility(View.VISIBLE);
        lay_signup.setVisibility(View.GONE);
        lay_otp.setVisibility(View.VISIBLE);
    }

    private boolean validateName() {
        if (edt_name.getText().toString().trim().isEmpty()) {
            input_layout_name.setError("Please Enter Name");
            requestFocus(edt_name);
            return false;
        } else {
            if (edt_name.getText().toString().trim().length() > 2) {
                input_layout_name.setErrorEnabled(false);
                return true;
            } else {
                input_layout_name.setError("Invalid Name");
                requestFocus(edt_name);
                return false;
            }
        }
    }

    private boolean validateAddress() {
        if (edt_address.getText().toString().trim().isEmpty()) {
            input_layout_address.setError("Please Enter Address");
            requestFocus(edt_address);
            return false;
        } else {
            if (edt_address.getText().toString().trim().length() > 3) {
                input_layout_address.setErrorEnabled(false);
                return true;
            } else {
                input_layout_address.setError("Invalid Address");
                requestFocus(edt_address);
                return false;
            }
        }
    }

    private boolean validatePassword() {
        if (edt_password.getText().toString().isEmpty()) {
            input_layout_password.setError("Please Enter Password");
            requestFocus(edt_password);
            return false;
        } else {
            if (edt_password.getText().toString().trim().length() >= 5) {
                input_layout_password.setErrorEnabled(false);
                return true;
            } else {
                input_layout_password.setError("Invalid Password");
                requestFocus(edt_password);
                return false;
            }
        }
    }

    private boolean validateConfirmPassword() {
        if (edt_confirm_password.getText().toString().trim().isEmpty()) {
            input_layout_confirm_password.setError("Please Enter Password Again");
            requestFocus(edt_confirm_password);
            return false;
        } else {
            if (edt_confirm_password.getText().toString().trim().equals(edt_password.getText().toString().trim())) {
                input_layout_confirm_password.setErrorEnabled(false);
                return true;
            } else {
                input_layout_confirm_password.setError("Password Does Not Matches");
                requestFocus(edt_confirm_password);
                return false;
            }
        }
    }

    private boolean validateMobile() {
        if (edt_mobile.getText().toString().trim().isEmpty()) {
            input_layout_mobile.setError("Please Enter Mobile Number");
            requestFocus(edt_mobile);
            return false;
        } else {
            if (edt_mobile.getText().toString().trim().length() == 10) {
                input_layout_mobile.setErrorEnabled(false);
                return true;
            } else {
                input_layout_mobile.setError("Invalid Mobile Number");
                requestFocus(edt_mobile);
                return false;
            }
        }
    }

    private boolean validateEmail() {
        String emailPattern = "^[_A-Za-z0-9-]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";
        if (edt_email.getText().toString().trim().isEmpty()) {
            input_layout_email.setError("Please Enter Email");
            requestFocus(edt_email);
            return false;
        } else {
            if (!edt_email.getText().toString().trim().matches(emailPattern)) {
                input_layout_email.setError("Invalid Email Address");
                requestFocus(edt_email);
                return false;
            } else {
                input_layout_email.setErrorEnabled(false);
            }
            return true;
        }
    }

    private void requestFocus(View view) {
        if (view.requestFocus()) {
            getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE);
        }
    }

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.txt_login) {
            Intent intent = new Intent(SignupActivity.this, LoginActivity.class);
            startActivity(intent);
            finish();
        } else if (v.getId() == R.id.btn_signup) {
            submitSignUp();
        } else if (v.getId() == R.id.btn_verify) {
            String otp1 = "";
            otp1 = edt_otp.getText().toString().trim();
            if (otp1.isEmpty()) {
                Toast.makeText(this, "please enter otp", Toast.LENGTH_SHORT).show();
            } else if (otp1.length() < 4) {
                Toast.makeText(this, "enter proper otp", Toast.LENGTH_SHORT).show();
            } else if (otp1.equals(otp)) {
                Toast.makeText(this, "please wait", Toast.LENGTH_SHORT).show();
                SignupManager.getInstance().sendSignupRequest(SignupActivity.this, name, email, mobile, password, address, appPreference.getTokenKey());
            } else {
                Toast.makeText(this, "please enter valid otp", Toast.LENGTH_SHORT).show();
            }
        }
    }

    @Override
    public void onSignupResponseReceived() {
        signup_layout.setVisibility(View.VISIBLE);
        signup_loader.setVisibility(View.GONE);
        appPreference.setUserId(SignupManager.getInstance().getmSignupResponsePojo().getId());
        appPreference.setName(name);
        appPreference.setEmail(email);
        appPreference.setAddress(address);
        appPreference.setMobile(mobile);
        Toast.makeText(SignupActivity.this, "Congratulations!!!", Toast.LENGTH_SHORT).show();
        Toast.makeText(SignupActivity.this, "You have successfully signed up", Toast.LENGTH_SHORT).show();
        finish();
    }

    @Override
    public void onSignupResponseFailed() {
        signup_layout.setVisibility(View.GONE);
        signup_loader.setVisibility(View.GONE);
        Toast.makeText(SignupActivity.this, R.string.something_went_wrong, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onUserAlreadyExsist() {
        signup_layout.setVisibility(View.VISIBLE);
        signup_loader.setVisibility(View.GONE);
        Toast.makeText(SignupActivity.this, "You are already a customer", Toast.LENGTH_SHORT).show();
        Toast.makeText(SignupActivity.this, "Please login using mobile number", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onSignupResponseTimeout() {
        signup_layout.setVisibility(View.GONE);
        signup_loader.setVisibility(View.GONE);
        Toast.makeText(SignupActivity.this, "Successfully Registered Please Login", Toast.LENGTH_SHORT).show();
        Intent intent=new Intent(this,LoginActivity.class);
        startActivity(intent);
    }

    @Override
    public void onOTPResponseReceived() {
        signup_layout.setVisibility(View.VISIBLE);
        lay_signup.setVisibility(View.GONE);
        lay_otp.setVisibility(View.VISIBLE);
        signup_loader.setVisibility(View.GONE);
        otp = SignupManager.getInstance().getmOtpResponsePojo().getOtp();
        Toast.makeText(this, "otp: " + otp, Toast.LENGTH_SHORT).show();
        Log.d("TAGG", "otp: " + otp);
    }

    @Override
    public void onOTPResponseFailed() {
        signup_layout.setVisibility(View.VISIBLE);
        lay_signup.setVisibility(View.VISIBLE);
        lay_otp.setVisibility(View.GONE);
        signup_loader.setVisibility(View.GONE);
        Toast.makeText(this, SignupManager.getInstance().getmOtpResponsePojo().getMsg(), Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onOTPResponseTimeout() {
        signup_layout.setVisibility(View.VISIBLE);
        lay_signup.setVisibility(View.VISIBLE);
        lay_otp.setVisibility(View.GONE);
        signup_loader.setVisibility(View.GONE);
        Toast.makeText(this, "check internet connection", Toast.LENGTH_SHORT).show();
    }

    class MyTextWatcher implements TextWatcher {

        private View view;

        private MyTextWatcher(View view) {
            this.view = view;
        }

        public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
        }

        public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
        }

        public void afterTextChanged(Editable editable) {
            switch (view.getId()) {
                case R.id.input_layout_email:
                    validateEmail();
                    break;
                case R.id.input_layout_password:
                    validatePassword();
                    break;
                case R.id.input_layout_confirm_password:
                    validateConfirmPassword();
                    break;
                case R.id.input_layout_name:
                    validateName();
                    break;
                case R.id.input_layout_mobile:
                    validateMobile();
                    break;
                case R.id.input_layout_address:
                    validateAddress();
                    break;
            }
        }
    }
}