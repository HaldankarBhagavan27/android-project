package www.scrimatec.cafe18.order_list;

import android.content.Context;

import com.android.volley.Request;
import com.google.gson.Gson;
import www.scrimatec.cafe18.network.NetworkManager;
import www.scrimatec.cafe18.network.NetworkResponseListener;

import org.json.JSONException;
import org.json.JSONObject;

public class OrderListManager implements NetworkResponseListener {
    private static OrderListManager mInstance;
    private OrderListResponseListener mOrderListResponseListener;
    private OrderListResponsePojo mOrderListResponsePojo;

    public static OrderListManager getInstance() {
        return (mInstance == null) ? mInstance = new OrderListManager() : mInstance;
    }

    public void registerOrderListListener(OrderListResponseListener orderListResponseListener) {
        NetworkManager.getInstance().registerListener(this);
        mOrderListResponseListener = orderListResponseListener;
    }

    public void deregisterOrderListListener() {
        NetworkManager.getInstance().deRegisterListener(this);
        mOrderListResponseListener = null;
    }

    public void sendOrderListRequest(Context context, String id) {
        Gson gson = new Gson();
        OrderListRequestPojo orderListRequestPojo = new OrderListRequestPojo(id);
        JSONObject jsonObject = null;
        try {
            jsonObject = new JSONObject(gson.toJson(orderListRequestPojo));
        } catch (JSONException e) {
            e.printStackTrace();
        }
        NetworkManager.getInstance().sendJsonObjectRequest(context, Request.Method.POST, NetworkManager.getInstance().getMyOrdersUrl(), jsonObject, NetworkManager.RequestType.MY_ORDERS);
    }

    public OrderListResponsePojo getmOrderListResponsePojo() {
        return mOrderListResponsePojo;
    }

    @Override
    public void onNetworkResponseReceived(String response, NetworkManager.RequestType requestType) {
        Gson gson = new Gson();
        if (requestType == NetworkManager.RequestType.MY_ORDERS) {
            if (mOrderListResponseListener == null)
                return;
            mOrderListResponsePojo = gson.fromJson(response, OrderListResponsePojo.class);
            if (mOrderListResponsePojo.getOrd_list().length > 0) {
                mOrderListResponseListener.onOrderListResponseReceived();
            } else {
                mOrderListResponseListener.onOrderListResponseFailed();
            }
        }
    }

    @Override
    public void onNetworkResponseFailed(NetworkManager.RequestType requestType) {
        if (requestType == NetworkManager.RequestType.MY_ORDERS) {
            mOrderListResponseListener.onOrderListResponseTimeout();
        }
    }
}