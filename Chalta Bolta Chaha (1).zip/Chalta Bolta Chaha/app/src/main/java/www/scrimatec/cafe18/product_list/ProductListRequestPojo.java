package www.scrimatec.cafe18.product_list;

public class ProductListRequestPojo {

    String id;

    public ProductListRequestPojo(String id) {
        this.id = id;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }
}
