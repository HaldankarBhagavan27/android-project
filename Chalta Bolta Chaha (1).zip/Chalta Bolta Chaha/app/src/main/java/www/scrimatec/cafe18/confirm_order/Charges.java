package www.scrimatec.cafe18.confirm_order;

/**
 * Created by Operand Technologies on 26/08/18.
 */

public class Charges {
    private String delivery_charges;

    private String tax;

    private String min_order;

    public String getDelivery_charges() {
        return delivery_charges;
    }

    public void setDelivery_charges(String delivery_charges) {
        this.delivery_charges = delivery_charges;
    }

    public String getTax() {
        return tax;
    }

    public void setTax(String tax) {
        this.tax = tax;
    }

    public String getMin_order() {
        return min_order;
    }

    public void setMin_order(String min_order) {
        this.min_order = min_order;
    }

    @Override
    public String toString() {
        return "ClassPojo [delivery_charges = " + delivery_charges + ", tax = " + tax + ", min_order = " + min_order + "]";
    }
}
