package www.scrimatec.cafe18.confirm_order;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import www.scrimatec.cafe18.R;
import www.scrimatec.cafe18.mycart.Cart;

import java.util.ArrayList;

public class InvoiceAdapter extends BaseAdapter {
    private Context context;
    private ArrayList<Cart> carts;
    private LayoutInflater mLayoutInflater;

    public InvoiceAdapter(Context context, ArrayList<Cart> carts) {
        this.context = context;
        this.carts = carts;
        mLayoutInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount() {
        return carts.size();
    }

    @Override
    public Object getItem(int position) {
        return carts.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        ViewHolder holder = null;
        if (convertView == null) {
            holder = new ViewHolder();
            convertView = mLayoutInflater.inflate(R.layout.invoice_row_layout, parent, false);
            convertView.setTag(holder);
            holder.txt_pname = convertView.findViewById(R.id.txt_pname);
            holder.txt_qty = convertView.findViewById(R.id.txt_qty);
            holder.txt_total = convertView.findViewById(R.id.txt_total);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }

        holder.txt_pname.setText((position + 1) + ". " + carts.get(position).getPname());
        holder.txt_qty.setText(carts.get(position).getQty());
        holder.txt_total.setText(String.valueOf((Double.valueOf(carts.get(position).getPrice()) * Integer.valueOf(carts.get(position).getQty()))));
        return convertView;
    }

    private class ViewHolder {
        private TextView txt_pname, txt_qty, txt_total;
    }
}