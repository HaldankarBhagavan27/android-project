package www.scrimatec.cafe18.profile;

import android.content.Context;

import com.android.volley.Request;
import com.google.gson.Gson;
import www.scrimatec.cafe18.network.NetworkManager;
import www.scrimatec.cafe18.network.NetworkResponseListener;

import org.json.JSONException;
import org.json.JSONObject;

public class UserProfileManager implements NetworkResponseListener {
    private static UserProfileManager mInstance;
    private UpdateProfileResponseListener mUpdateProfileResponseListener;
    private UpdateProfileResponsePojo mUpdateProfileResponsePojo;

    public static UserProfileManager getInstance() {
        return (mInstance == null) ? mInstance = new UserProfileManager() : mInstance;
    }

    public void registerUpdateProfileListener(UpdateProfileResponseListener updateProfileResponseListener) {
        NetworkManager.getInstance().registerListener(this);
        mUpdateProfileResponseListener = updateProfileResponseListener;
    }

    public void deregisterUpdateProfileListener() {
        NetworkManager.getInstance().deRegisterListener(this);
        mUpdateProfileResponseListener = null;
    }

    public void sendUpdateProfileRequest(Context context, String userId, String fName, String mobile, String address, String email) {
        Gson gson = new Gson();
        UpdateProfileRequestPojo requestPojo = new UpdateProfileRequestPojo(userId, fName, mobile, address, email);
        JSONObject jsonObject = null;
        try {
            jsonObject = new JSONObject(gson.toJson(requestPojo));
        } catch (JSONException e) {
            e.printStackTrace();
        }
        NetworkManager.getInstance().sendJsonObjectRequest(context, Request.Method.POST, NetworkManager.getInstance().getUpdateProfileUrl(), jsonObject, NetworkManager.RequestType.UPDATE_PROFILE);
    }

    @Override
    public void onNetworkResponseReceived(String response, NetworkManager.RequestType requestType) {
        Gson gson = new Gson();
        if (requestType == NetworkManager.RequestType.UPDATE_PROFILE) {
            if (mUpdateProfileResponseListener == null)
                return;
            mUpdateProfileResponsePojo = gson.fromJson(response, UpdateProfileResponsePojo.class);
            if (mUpdateProfileResponsePojo.getSt().equals("1")) {
                mUpdateProfileResponseListener.onUpdateProfileResponseReceived();
            } else {
                mUpdateProfileResponseListener.onUpdateProfileResponseFailed();
            }
        }
    }

    @Override
    public void onNetworkResponseFailed(NetworkManager.RequestType requestType) {
        if (requestType == NetworkManager.RequestType.UPDATE_PROFILE) {
            mUpdateProfileResponseListener.onUpdateProfileTimeoutReceived();
        }
    }
}