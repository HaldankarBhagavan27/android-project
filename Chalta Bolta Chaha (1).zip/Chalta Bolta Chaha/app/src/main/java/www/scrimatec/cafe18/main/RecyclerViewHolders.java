package www.scrimatec.cafe18.main;

import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.TextView;

import com.android.volley.toolbox.NetworkImageView;
import www.scrimatec.cafe18.R;
import www.scrimatec.cafe18.product_list.ProductListActivity;

public class RecyclerViewHolders extends RecyclerView.ViewHolder implements View.OnClickListener {

    public TextView txt_cat;
    public NetworkImageView img_cat;

    public RecyclerViewHolders(View itemView) {
        super(itemView);
        itemView.setOnClickListener(this);
        txt_cat = itemView.findViewById(R.id.txt_cat);
        img_cat = itemView.findViewById(R.id.img_cat);
    }

    @Override
    public void onClick(View view) {
        Intent intent = new Intent(view.getContext(), ProductListActivity.class);
        intent.putExtra("pos", getAdapterPosition());
        intent.putExtra("id", CategoryManager.getInstance().getmCategoryResponsePojo().getCat_list()[getPosition()].getId());
        intent.putExtra("name", CategoryManager.getInstance().getmCategoryResponsePojo().getCat_list()[getPosition()].getName());
        view.getContext().startActivity(intent);
    }
}
