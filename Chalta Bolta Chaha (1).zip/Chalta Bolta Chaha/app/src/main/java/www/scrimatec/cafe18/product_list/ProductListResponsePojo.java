package www.scrimatec.cafe18.product_list;

import java.util.ArrayList;

public class ProductListResponsePojo {
    private ArrayList<Prod_list> prod_list;

    public ArrayList<Prod_list> getProd_list ()
    {
        return prod_list;
    }

    public void setProd_list (ArrayList<Prod_list> prod_list)
    {
        this.prod_list = prod_list;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [prod_list = "+prod_list+"]";
    }
}
