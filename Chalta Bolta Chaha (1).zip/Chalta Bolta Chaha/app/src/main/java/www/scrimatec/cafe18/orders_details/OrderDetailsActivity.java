package www.scrimatec.cafe18.orders_details;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.github.paolorotolo.expandableheightlistview.ExpandableHeightListView;
import com.github.ybq.android.spinkit.SpinKitView;
import www.scrimatec.cafe18.R;
import www.scrimatec.cafe18.mycart.Cart;
import www.scrimatec.cafe18.mycart.CartDatabaseHandler;

//import uk.co.chrisjenx.calligraphy.CalligraphyContextWrapper;

public class OrderDetailsActivity extends AppCompatActivity implements OrderDetailsResponseListener {
    private Button btn_repear_order;
    private String inv_no;
    private ScrollView scrl_ord_details;
    private SpinKitView order_details_loader;
    private TextView txt_invno, txt_status, txt_date, txt_total_price, txt_cust_name, txt_mob, txt_addr, txt_delivery_date, txt_delivery, txt_tax;
    private Toolbar toolbar;
    private ImageView img_back_arrow;
    private TextView txt_title;
    private RelativeLayout lay_toolbar_cart;
    private OrderDetailsAdapter orderDetailsAdapter;
    private Order_details[] order_details;
    private ExpandableHeightListView order_details_listview;
    private double total = 0;
    private CartDatabaseHandler cartDatabaseHandler;

//    @Override
//    protected void attachBaseContext(Context newBase) {
//        super.attachBaseContext(CalligraphyContextWrapper.wrap(newBase));
//    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order_details);

        inv_no = getIntent().getStringExtra("inv_no");
        cartDatabaseHandler = new CartDatabaseHandler(this);
        btn_repear_order = findViewById(R.id.btn_repear_order);
        txt_status = findViewById(R.id.txt_status);
        txt_invno = findViewById(R.id.txt_invno);
        txt_date = findViewById(R.id.txt_date);
        txt_total_price = findViewById(R.id.txt_total_price);
        txt_cust_name = findViewById(R.id.txt_cust_name);
        txt_mob = findViewById(R.id.txt_mob);
        txt_addr = findViewById(R.id.txt_addr);
        txt_delivery = findViewById(R.id.txt_delivery);
        txt_tax = findViewById(R.id.txt_tax);
        txt_delivery_date = findViewById(R.id.txt_delivery_date);
        scrl_ord_details = findViewById(R.id.scrl_ord_details);
        order_details_loader = findViewById(R.id.order_details_loader);
        order_details_listview = findViewById(R.id.order_details_listview);
        toolbar = findViewById(R.id.app_bar);
        img_back_arrow = toolbar.findViewById(R.id.img_back_arrow);
        img_back_arrow.setVisibility(View.VISIBLE);
        img_back_arrow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        txt_title = toolbar.findViewById(R.id.txt_title);
        txt_title.setText("Order Details");
        lay_toolbar_cart = toolbar.findViewById(R.id.lay_toolbar_cart);
        lay_toolbar_cart.setVisibility(View.INVISIBLE);
        final String payeeAddress = "vishakhamore95@okicici";
        final String payeeName = "Vishakha More";
        final String transactionNote = "Barbie Boutique";

        final String currencyUnit = "INR";

        OrderDetailsManager.getInstance().registerOrderDetailsListener(this);
        OrderDetailsManager.getInstance().sendOrderDetailsRequest(OrderDetailsActivity.this, inv_no);
        scrl_ord_details.setVisibility(View.GONE);
        order_details_loader.setVisibility(View.VISIBLE);
        btn_repear_order.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                for (int i = 0; i < order_details.length; i++) {
                    Cart cart = new Cart();
                    cart.setProdId(order_details[i].getProduct_id());
                    cart.setPname(order_details[i].getPname());
                    cart.setUrl("");
                    cart.setQty(order_details[i].getQuantity());
                    cart.setUnit(order_details[i].getPunit());
                    cart.setPrice(order_details[i].getPrice());
                    cartDatabaseHandler.addToCart(cart);
                }
                Toast.makeText(OrderDetailsActivity.this, "New order created, please check your basket...", Toast.LENGTH_SHORT).show();
            }
        });


    }

    @Override
    public void onOrderDetailsResponseReceived() {
        scrl_ord_details.setVisibility(View.VISIBLE);
        order_details_loader.setVisibility(View.GONE);
        order_details = OrderDetailsManager.getInstance().getmOrderDetailsResponsePojo().getOrder_details();
        if (order_details[0].getStatus().equals("1")) {
            txt_status.setText("Status : Pending");
        } else if (order_details[0].getStatus().equals("2")) {
            txt_status.setText("Status : Confirmed");
        } else if (order_details[0].getStatus().equals("3")) {
            txt_status.setText("Status : In Shipping");
        } else if (order_details[0].getStatus().equals("4")) {
            txt_status.setText("Status : Delivered");
        } else if (order_details[0].getStatus().equals("5")) {
            txt_status.setText("Status : Cancelled by supplier");
        } else if (order_details[0].getStatus().equals("6")) {
            txt_status.setText("Status : Cancelled by you");
        }
        txt_invno.setText("Invoice No. : " + OrderDetailsManager.getInstance().getmOrderDetailsResponsePojo().getOrder_details()[0].getInvoice_num());
        txt_cust_name.setText("Name : " + OrderDetailsManager.getInstance().getmOrderDetailsResponsePojo().getOrder_details()[0].getName());
        txt_mob.setText("Mobile : " + OrderDetailsManager.getInstance().getmOrderDetailsResponsePojo().getOrder_details()[0].getMob());
        txt_addr.setText("Address : " + OrderDetailsManager.getInstance().getmOrderDetailsResponsePojo().getOrder_details()[0].getAddr());
        txt_delivery_date.setText("Delivery Date : " + OrderDetailsManager.getInstance().getmOrderDetailsResponsePojo().getOrder_details()[0].getDate());
        for (int i = 0; i < order_details.length; i++) {
            total = total + (Double.valueOf(order_details[i].getPrice()) * Integer.valueOf(order_details[i].getQuantity()));
        }
        txt_delivery.setText("₹ " + order_details[0].getDelivery_charges());
        txt_tax.setText("₹ " + order_details[0].getTax());
        total = total + Double.valueOf(order_details[0].getDelivery_charges());
        txt_total_price.setText("₹ " + total);
        orderDetailsAdapter = new OrderDetailsAdapter(OrderDetailsActivity.this, order_details);
        order_details_listview.setAdapter(orderDetailsAdapter);
        order_details_listview.setExpanded(true);
        order_details_listview.setFocusable(false);
    }

    @Override
    public void onOrderDetailsResponseFailed() {
        scrl_ord_details.setVisibility(View.GONE);
        order_details_loader.setVisibility(View.GONE);
    }

    @Override
    public void onOrderDetailsResponseTimeout() {
        scrl_ord_details.setVisibility(View.GONE);
        order_details_loader.setVisibility(View.GONE);
    }

}