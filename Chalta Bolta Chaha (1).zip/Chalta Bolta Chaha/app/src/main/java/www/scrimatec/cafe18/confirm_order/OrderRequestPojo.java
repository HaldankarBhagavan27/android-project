package www.scrimatec.cafe18.confirm_order;

public class OrderRequestPojo {
    String pid;
    String price;
    String quantity;
    String name;
    String mob;
    String addr;
    String date;
    String userid;
    String delivery_charges;
    String tax;

    public OrderRequestPojo(String pid, String price, String quantity, String name, String mob, String addr, String date, String userid, String delivery_charges, String tax) {
        this.pid = pid;
        this.price = price;
        this.quantity = quantity;
        this.name = name;
        this.mob = mob;
        this.addr = addr;
        this.date = date;
        this.userid = userid;
        this.delivery_charges = delivery_charges;
        this.tax = tax;
    }

    public String getDelivery_charges() {
        return delivery_charges;
    }

    public void setDelivery_charges(String delivery_charges) {
        this.delivery_charges = delivery_charges;
    }

    public String getPid() {
        return pid;
    }

    public void setPid(String pid) {
        this.pid = pid;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getQuantity() {
        return quantity;
    }

    public void setQuantity(String quantity) {
        this.quantity = quantity;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getMob() {
        return mob;
    }

    public void setMob(String mob) {
        this.mob = mob;
    }

    public String getAddr() {
        return addr;
    }

    public void setAddr(String addr) {
        this.addr = addr;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getUserid() {
        return userid;
    }

    public void setUserid(String userid) {
        this.userid = userid;
    }

    public String getTax() {
        return tax;
    }

    public void setTax(String tax) {
        this.tax = tax;
    }
}
