package www.scrimatec.cafe18.login;

public class LoginRequestPojo {
    String mob;
    String pass;
    String token;

    public LoginRequestPojo(String mobile, String password, String token) {
        this.mob = mobile;
        this.pass = password;
        this.token = token;
    }

    public String getMobile() {
        return mob;
    }

    public void setMobile(String mobile) {
        this.mob = mobile;
    }

    public String getPassword() {
        return pass;
    }

    public void setPassword(String password) {
        this.pass = password;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }
}
