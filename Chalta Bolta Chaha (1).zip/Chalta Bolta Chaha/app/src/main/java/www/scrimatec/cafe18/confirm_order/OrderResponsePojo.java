package www.scrimatec.cafe18.confirm_order;

public class OrderResponsePojo {
    String st;

    public String getSt() {
        return st;
    }

    public void setSt(String st) {
        this.st = st;
    }
}
