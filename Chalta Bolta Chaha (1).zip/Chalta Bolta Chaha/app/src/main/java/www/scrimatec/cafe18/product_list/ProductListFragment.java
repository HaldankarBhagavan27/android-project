package www.scrimatec.cafe18.product_list;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.google.gson.Gson;
import www.scrimatec.cafe18.R;
import www.scrimatec.cafe18.network.NetworkManager;
import www.scrimatec.cafe18.utils.MandaiController;

import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by tushar on 15/09/18.
 */

public class ProductListFragment extends Fragment {
    private String categoryId = "0";
    private ListView productList;
    private String mobile_no="0";

    public ProductListFragment() {
    }

    @SuppressLint("ValidFragment")
    public ProductListFragment(String categoryId,String mobile_no) {
        this.categoryId = categoryId;
        this.mobile_no = mobile_no;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        Log.d("TAGG", "####categoryId: " + categoryId);
        System.out.println("Oncreatetestlog onCreate() Restoring previous state");
        View view = inflater.inflate(R.layout.fragment_product_list, container, false);
        productList = view.findViewById(R.id.productList);
        fetchProducts();
        return view;
    }

    public void fetchProducts() {
        Map<String, String> jsonParams = new HashMap<String, String>();
        jsonParams.put("id", categoryId);
        jsonParams.put("mob", mobile_no);

        //jsonParams.put("mob",mobile_no);
        Log.d("TAGG", "jsonParams: " + jsonParams.toString());
        JsonObjectRequest objectRequest = new JsonObjectRequest(Request.Method.POST, NetworkManager.getInstance().getProductUrl(), new JSONObject(jsonParams), new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                Log.d("TUSHAR", "response: " + response);
                Gson gson = new Gson();
                try {
                    ProductListResponsePojo mProductListResponsePojo = gson.fromJson(response.toString(), ProductListResponsePojo.class);
                    if (mProductListResponsePojo != null) {
                        if (mProductListResponsePojo.getProd_list() != null)
                            if (!mProductListResponsePojo.getProd_list().isEmpty()) {
                                ProductListAdapter productListAdapter = new ProductListAdapter(getActivity(), mProductListResponsePojo.getProd_list());
                                productList.setAdapter(productListAdapter);

                            }
                    }
                }catch (Exception e){

                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.e("TAG", "onErrorResponse: ", error);
            }
        }) {
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                HashMap<String, String> header = new HashMap<String, String>();
                header.put("Content-Type", "application/json");
                return header;
            }
        };
        MandaiController.getInstance().addToRequestQueue(objectRequest, "header");
    }
}