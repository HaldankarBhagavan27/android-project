package www.scrimatec.cafe18.order_list;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.github.ybq.android.spinkit.SpinKitView;
import www.scrimatec.cafe18.R;
import www.scrimatec.cafe18.orders_details.OrderDetailsActivity;
import www.scrimatec.cafe18.utils.AppPreference;

//import uk.co.chrisjenx.calligraphy.CalligraphyContextWrapper;

public class OrderListActivity extends AppCompatActivity implements OrderListResponseListener, AdapterView.OnItemClickListener {
    private Toolbar toolbar;
    private ImageView img_back_arrow;
    private TextView txt_title;
    private RelativeLayout lay_toolbar_cart;
    private AppPreference appPreference;
    private ListView my_order_list;
    private SpinKitView my_order_loader;
    private OrderListAdapter orderListAdapter;

//    @Override
//    protected void attachBaseContext(Context newBase) {
//        super.attachBaseContext(CalligraphyContextWrapper.wrap(newBase));
//    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_orders);

        appPreference = new AppPreference(OrderListActivity.this);
        toolbar = findViewById(R.id.app_bar);
        img_back_arrow = toolbar.findViewById(R.id.img_back_arrow);
        img_back_arrow.setVisibility(View.VISIBLE);
        txt_title = toolbar.findViewById(R.id.txt_title);
        txt_title.setText("My Orders");
        lay_toolbar_cart = toolbar.findViewById(R.id.lay_toolbar_cart);
        lay_toolbar_cart.setVisibility(View.INVISIBLE);
        my_order_list = findViewById(R.id.my_order_list);
        my_order_list.setOnItemClickListener(this);
        my_order_loader = findViewById(R.id.my_order_loader);
        img_back_arrow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        OrderListManager.getInstance().registerOrderListListener(this);
        OrderListManager.getInstance().sendOrderListRequest(OrderListActivity.this, appPreference.getUserId());
        my_order_list.setVisibility(View.GONE);
        my_order_loader.setVisibility(View.VISIBLE);
    }

    @Override
    public void onOrderListResponseReceived() {
        my_order_list.setVisibility(View.VISIBLE);
        my_order_loader.setVisibility(View.GONE);
        orderListAdapter = new OrderListAdapter(OrderListActivity.this, OrderListManager.getInstance().getmOrderListResponsePojo().getOrd_list());
        my_order_list.setAdapter(orderListAdapter);
    }

    @Override
    public void onOrderListResponseFailed() {
        my_order_list.setVisibility(View.GONE);
        my_order_loader.setVisibility(View.GONE);
    }

    @Override
    public void onOrderListResponseTimeout() {
        my_order_list.setVisibility(View.GONE);
        my_order_loader.setVisibility(View.GONE);
    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        Intent intent = new Intent(this, OrderDetailsActivity.class);
        intent.putExtra("inv_no", OrderListManager.getInstance().getmOrderListResponsePojo().getOrd_list()[position].getInvoice_num());
        startActivity(intent);
    }
}
