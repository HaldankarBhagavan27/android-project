package www.scrimatec.cafe18.product_list;

import android.content.Context;
import android.content.Intent;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.style.StrikethroughSpan;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.toolbox.ImageLoader;
import com.android.volley.toolbox.NetworkImageView;
import www.scrimatec.cafe18.R;
import www.scrimatec.cafe18.mycart.Cart;
import www.scrimatec.cafe18.mycart.CartDatabaseHandler;
import www.scrimatec.cafe18.product_details.ProductDetailsActivity;
import www.scrimatec.cafe18.utils.MandaiController;

import java.util.ArrayList;
import java.util.Locale;

public class ProductListAdapter extends BaseAdapter {
    private Context context;
    private ArrayList<Prod_list> prod_list;
    private ArrayList<Prod_list> tempArrayLists;
    private LayoutInflater mLayoutInflater;
    private CartDatabaseHandler cartDatabaseHandler;
    private ImageLoader imageLoader = MandaiController.getInstance().getImageLoader();
    private CallbackInterface mCallback;

    public ProductListAdapter(Context context, ArrayList<Prod_list> prod_list) {
        this.context = context;
        this.prod_list = prod_list;
        tempArrayLists = new ArrayList<>();
        tempArrayLists.addAll(prod_list);
        cartDatabaseHandler = new CartDatabaseHandler(context);
        try{
            mCallback = (CallbackInterface) context;
        }catch(ClassCastException ex){
            //.. should log the error or throw and exception
            Log.e("MyAdapter","Must implement the CallbackInterface in the Activity", ex);
        }
        mLayoutInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount() {
        return prod_list.size();
    }

    @Override
    public Object getItem(int position) {
        return prod_list.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        ViewHolder holder = null;
        if (convertView == null) {
            holder = new ViewHolder();
            convertView = mLayoutInflater.inflate(R.layout.products_row_layout, parent, false);
            convertView.setTag(holder);

            holder.prod_1_layout = convertView.findViewById(R.id.prod_1_layout);
            holder.txt_prod1_name = convertView.findViewById(R.id.txt_prod1_name);
            holder.txt_prod1_price = convertView.findViewById(R.id.txt_prod1_price);
            holder.txt_prod_percent = convertView.findViewById(R.id.txt_prod_percent);
            holder.txt_prod2_price = convertView.findViewById(R.id.txt_prod2_price);
            holder.img_prod1 = convertView.findViewById(R.id.img_prod1);
            holder.img_add = convertView.findViewById(R.id.img_add);
            holder.img_minus = convertView.findViewById(R.id.img_minus);
            holder.txt_quantity = convertView.findViewById(R.id.txt_quantity);
            holder.spinner_unit = convertView.findViewById(R.id.spinner_unit);
            holder.btn_add = convertView.findViewById(R.id.btn_add);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }

        holder.txt_prod1_name.setText(prod_list.get(position).getName() + " / " + prod_list.get(position).getMar_name());
        holder.txt_prod_percent.setText("("+prod_list.get(position).getArr_percentage_price()[0].getPercentage()+" % OFF)");
        try {
            String old_price = "₹ " + Float.valueOf(prod_list.get(position).getArr_old_price()[0].getOld_price().replaceAll(".//", "")) + "/" + prod_list.get(position).getArr_quant()[0].getQuant() + "";
            SpannableStringBuilder ssBuilder = new SpannableStringBuilder(old_price);
            // Initialize a new StrikeThroughSpan to display strike through text
            StrikethroughSpan strikethroughSpan = new StrikethroughSpan();
            // Apply the strike through text to the span
            ssBuilder.setSpan(
                    strikethroughSpan, // Span to add
                    0, // Start of the span (inclusive)
                    old_price.length(), // End of the span (exclusive)
                    Spanned.SPAN_EXCLUSIVE_EXCLUSIVE // Do not extend the span when text add later
            );
            holder.txt_prod2_price.setText(ssBuilder);
            holder.txt_prod1_price.setText("₹ " + Float.valueOf(prod_list.get(position).getArr_price()[0].getPrice().replaceAll(".//", "")) + "/" + prod_list.get(position).getArr_quant()[0].getQuant() + "" /*+ prod_list.get(position).getUnit().split("#")[0]*/);

        }catch (NumberFormatException e){}
        holder.img_prod1.setDefaultImageResId(R.mipmap.ic_launcher);
        holder.txt_quantity.setText(String.valueOf(0));
        ArrayList<String> units = new ArrayList<>();
        for (int i = 0; i < prod_list.get(position).getArr_unit().length; i++)
            units.add(prod_list.get(position).getArr_unit()[i].getUnit());
        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(context, android.R.layout.simple_spinner_item, units);
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        holder.spinner_unit.setAdapter(dataAdapter);
        final ViewHolder finalHolder1 = holder;
        holder.spinner_unit.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                finalHolder1.txt_prod1_price.setText("₹ " + Float.valueOf(prod_list.get(position).getArr_price()[i].getPrice().replaceAll(".//", "")) + "/" + prod_list.get(position).getArr_quant()[i].getQuant() + "" /*+ prod_list.get(position).getUnit().split("#")[0]*/);
                finalHolder1.txt_prod_percent.setText("("+prod_list.get(position).getArr_percentage_price()[i].getPercentage()+" % OFF)");
                try {

                    String old_price = "₹ " + Float.valueOf(prod_list.get(position).getArr_old_price()[i].getOld_price().replaceAll(".//", "")) + "/" + prod_list.get(position).getArr_quant()[i].getQuant() + "";
                    SpannableStringBuilder ssBuilder = new SpannableStringBuilder(old_price);
                    // Initialize a new StrikeThroughSpan to display strike through text
                    StrikethroughSpan strikethroughSpan = new StrikethroughSpan();
                    // Apply the strike through text to the span
                    ssBuilder.setSpan(
                            strikethroughSpan, // Span to add
                            0, // Start of the span (inclusive)
                            old_price.length(), // End of the span (exclusive)
                            Spanned.SPAN_EXCLUSIVE_EXCLUSIVE // Do not extend the span when text add later
                    );
                    finalHolder1.txt_prod2_price.setText(ssBuilder);
                }catch (NumberFormatException e){}            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
        try {
            Log.d("TAGG", "prod_list.get(position).getImg_url(): " + prod_list.get(position).getImg_url());
            if (!prod_list.get(position).getImg_url().isEmpty())
                holder.img_prod1.setImageUrl(prod_list.get(position).getImg_url().replace("http://milkbar.scrimatec.com/mutha_bros/pic/product", "http://milkbar.scrimatec.com/mutha_bros/pic/product"), imageLoader);
        } catch (Exception e) {
            Toast.makeText(context, "error while loading image", Toast.LENGTH_SHORT).show();
            e.printStackTrace();
        }

        final ViewHolder finalHolder = holder;
        final ViewHolder finalHolder2 = holder;
        holder.img_add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (Integer.parseInt(finalHolder2.txt_quantity.getText().toString().trim()) >= 99) {

                } else {
                    finalHolder2.txt_quantity.setText(String.valueOf((Integer.valueOf(finalHolder2.txt_quantity.getText().toString().trim()) + 1)));
                }
                Log.d("TAGG", "add clicked: " + finalHolder2.txt_quantity.getText().toString().trim());
            }
        });

        holder.img_minus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (Integer.parseInt(finalHolder2.txt_quantity.getText().toString().trim()) == 1) {

                } else {
                    finalHolder2.txt_quantity.setText(String.valueOf((Integer.valueOf(finalHolder2.txt_quantity.getText().toString().trim()) - 1)));
                }
                Log.d("TAGG", "minus clicked: " + finalHolder2.txt_quantity.getText().toString().trim());
            }
        });

        final ViewHolder finalHolder3 = holder;
        final ViewHolder finalHolder4 = holder;
        holder.btn_add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                cartDatabaseHandler.addToCart(new Cart(prod_list.get(position).getId(), prod_list.get(position).getName(), prod_list.get(position).getImg_url(), String.valueOf(Integer.valueOf(finalHolder3.txt_quantity.getText().toString().trim())), finalHolder4.txt_prod1_price.getText().toString().trim().replaceAll("₹ ", "").split("/")[1], finalHolder4.txt_prod1_price.getText().toString().trim().replaceAll("₹ ", "").split("/")[0]));
                mCallback.onHandleSelection();
                Toast.makeText(context, "Product added to Basket", Toast.LENGTH_SHORT).show();
            }
        });

        holder.prod_1_layout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, ProductDetailsActivity.class);
                intent.putExtra("productId", prod_list.get(position).getId());
                intent.putExtra("name", prod_list.get(position).getName());
                context.startActivity(intent);
            }
        });
        return convertView;
    }

    private class ViewHolder {
        private LinearLayout prod_1_layout;
        private TextView txt_prod1_name, txt_prod2_price,txt_prod1_price, txt_quantity, txt_prod_percent;
        private NetworkImageView img_prod1;
        private ImageView img_minus, img_add;
        private Spinner spinner_unit;
        private Button btn_add;
    }

    public void getFilter(String charText) {
        charText = charText.toLowerCase(Locale.getDefault());
        prod_list.clear();
        if (charText.length() == 0) {
            prod_list.addAll(tempArrayLists);
        } else {
            for (Prod_list data : tempArrayLists) {
                if (data.getName().toLowerCase(Locale.getDefault()).contains(charText) ||
                        data.getDescription().toLowerCase(Locale.getDefault()).contains(charText)) {
                    prod_list.add(data);
                }
            }
        }
        notifyDataSetChanged();
    }

    public interface CallbackInterface{
        /**
         * Callback invoked when clicked
         */
        void onHandleSelection();
    }
}

