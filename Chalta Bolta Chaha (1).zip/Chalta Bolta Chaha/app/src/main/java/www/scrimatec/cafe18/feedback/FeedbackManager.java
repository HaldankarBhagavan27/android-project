package www.scrimatec.cafe18.feedback;

import android.content.Context;

import com.android.volley.Request;
import com.google.gson.Gson;
import www.scrimatec.cafe18.network.NetworkManager;
import www.scrimatec.cafe18.network.NetworkResponseListener;

import org.json.JSONException;
import org.json.JSONObject;

public class FeedbackManager implements NetworkResponseListener {
    private static FeedbackManager mInstance;
    private FeedbackResponseListener mFeedbackResponseListener;
    private FeedbackResponsePojo mFeedbackResponsePojo;

    public static FeedbackManager getInstance() {
        return (mInstance == null) ? mInstance = new FeedbackManager() : mInstance;
    }

    public void registerFeedbackListener(FeedbackResponseListener feedbackResponseListener) {
        NetworkManager.getInstance().registerListener(this);
        mFeedbackResponseListener = feedbackResponseListener;
    }

    public void deregisterFeedbackListener() {
        NetworkManager.getInstance().deRegisterListener(this);
        mFeedbackResponseListener = null;
    }

    public void sendFeedbackRequest(Context context, String userId, String sub, String msg, String date) {
        Gson gson = new Gson();
        FeedbackRequestPojo feedbackRequestPojo = new FeedbackRequestPojo(userId, sub, msg, date);
        JSONObject jsonObject = null;
        try {
            jsonObject = new JSONObject(gson.toJson(feedbackRequestPojo));
        } catch (JSONException e) {
            e.printStackTrace();
        }
        NetworkManager.getInstance().sendJsonObjectRequest(context, Request.Method.POST, NetworkManager.getInstance().getFeedbackUrl(), jsonObject, NetworkManager.RequestType.FEEDBACK);
    }

    @Override
    public void onNetworkResponseReceived(String response, NetworkManager.RequestType requestType) {
        Gson gson = new Gson();
        if (requestType == NetworkManager.RequestType.FEEDBACK) {
            if (mFeedbackResponseListener == null)
                return;
            mFeedbackResponsePojo = gson.fromJson(response, FeedbackResponsePojo.class);
            if (mFeedbackResponsePojo.getSt().equals("1")) {
                mFeedbackResponseListener.onFeedbackResponseReceived();
            } else {
                mFeedbackResponseListener.onFeedbackResponseFailed();
            }
        }
    }

    @Override
    public void onNetworkResponseFailed(NetworkManager.RequestType requestType) {
        if (requestType == NetworkManager.RequestType.FEEDBACK) {
            mFeedbackResponseListener.onFeedbackResponseTimeout();
        }
    }
}