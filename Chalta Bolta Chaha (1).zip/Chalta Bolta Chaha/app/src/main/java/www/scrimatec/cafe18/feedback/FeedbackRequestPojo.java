package www.scrimatec.cafe18.feedback;

public class FeedbackRequestPojo {
    String userid;
    String sub;
    String msg;
    String date;

    public FeedbackRequestPojo(String userId, String sub, String msg, String date) {
        this.userid = userId;
        this.sub = sub;
        this.msg = msg;
        this.date = date;
    }

    public String getUserid() {
        return userid;
    }

    public void setUserid(String userid) {
        this.userid = userid;
    }

    public String getSub() {
        return sub;
    }

    public void setSub(String sub) {
        this.sub = sub;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }
}
