package www.scrimatec.cafe18.login;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.TextInputLayout;
import android.support.v7.app.AppCompatActivity;
import android.text.Editable;
import android.text.TextWatcher;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.github.ybq.android.spinkit.SpinKitView;
import www.scrimatec.cafe18.R;
import www.scrimatec.cafe18.signup.SignupActivity;
import www.scrimatec.cafe18.utils.AppPreference;

//import uk.co.chrisjenx.calligraphy.CalligraphyContextWrapper;

public class LoginActivity extends AppCompatActivity implements View.OnClickListener, LoginResponseListener {
    private TextInputLayout input_layout_mobile, input_layout_password;
    private EditText edt_mobile, edt_password;
    private Button btn_login;
    private TextView txt_login, txt_member;
    private String mobile, password;
    private AppPreference appPreference;
    private ScrollView login_layout;
    private SpinKitView signup_loader;
    private boolean showPass = false;
    private ImageView img_show_password;
    private LinearLayout lay_not_member;

//    @Override
//    protected void attachBaseContext(Context newBase) {
//        super.attachBaseContext(CalligraphyContextWrapper.wrap(newBase));
//    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        this.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);

        View view = this.getCurrentFocus();
        if (view != null) {
            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
        }
        input_layout_mobile = findViewById(R.id.input_layout_mobile);
        input_layout_password = findViewById(R.id.input_layout_password);
        edt_mobile = findViewById(R.id.edt_mobile);
        edt_password = findViewById(R.id.edt_password);
        edt_password.setTransformationMethod(new PasswordTransformationMethod());
        btn_login = findViewById(R.id.btn_login);
        btn_login.setOnClickListener(this);
        txt_login = findViewById(R.id.txt_login);
        txt_login.setOnClickListener(this);
        lay_not_member = findViewById(R.id.lay_not_member);
        txt_member = findViewById(R.id.txt_member);
        appPreference = new AppPreference(LoginActivity.this);
        login_layout = findViewById(R.id.login_layout);
        signup_loader = findViewById(R.id.signup_loader);
        img_show_password = findViewById(R.id.img_show_password);
        img_show_password.setOnClickListener(this);

        edt_mobile.addTextChangedListener(new MyTextWatcher(edt_mobile));
        edt_password.addTextChangedListener(new MyTextWatcher(edt_password));

        LoginManager.getInstance().registerLoginListener(this);

        
    }

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.txt_login) {
            Intent intent = new Intent(LoginActivity.this, SignupActivity.class);
            startActivity(intent);


            finish();
        } else if (v.getId() == R.id.btn_login) {
            submitLogin();
        } else if (v.getId() == R.id.img_show_password) {
            if (showPass == false) {
                edt_password.setTransformationMethod(PasswordTransformationMethod.getInstance());
                showPass = true;
            } else {
                edt_password.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                showPass = false;
            }
        }
    }

    private void submitLogin() {
        View view = this.getCurrentFocus();
        if (view != null) {
            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
        }
        if (!validateMobile()) {
            return;
        }
        if (!validatePassword()) {
            return;
        }
        mobile = edt_mobile.getText().toString().trim();
        password = edt_password.getText().toString().trim();
        LoginManager.getInstance().sendLoginRequest(LoginActivity.this, mobile, password, "0");
        login_layout.setVisibility(View.GONE);
        signup_loader.setVisibility(View.VISIBLE);
    }

    private boolean validateMobile() {
        if (edt_mobile.getText().toString().trim().isEmpty()) {
            input_layout_mobile.setError("Please Enter Mobile Number");
            requestFocus(edt_mobile);
            return false;
        } else {
            if (edt_mobile.getText().toString().trim().length() == 10) {
                if (edt_mobile.getText().toString().trim().startsWith("00")) {
                    input_layout_mobile.setError("Invalid Mobile Number");
                    requestFocus(edt_mobile);
                    return false;
                } else {
                    input_layout_mobile.setErrorEnabled(false);
                    return true;
                }
            } else {
                input_layout_mobile.setError("Invalid Mobile Number");
                requestFocus(edt_mobile);
                return false;
            }
        }
    }

    private boolean validatePassword() {
        if (edt_password.getText().toString().isEmpty()) {
            input_layout_password.setError("Please Enter Password");
            requestFocus(edt_password);
            return false;
        } else {
            if (edt_password.getText().toString().trim().length() >= 5) {
                input_layout_password.setErrorEnabled(false);
                return true;
            } else {
                input_layout_password.setError("Enter at least 5 digits");
                requestFocus(edt_password);
                return false;
            }
        }
    }

    private void requestFocus(View view) {
        if (view.requestFocus()) {
            getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE);
        }
    }

    @Override
    public void onLoginResponseReceived() {
        login_layout.setVisibility(View.VISIBLE);
        signup_loader.setVisibility(View.GONE);
        appPreference.setUserId(LoginManager.getInstance().getmLoginResponsePojo().getData()[0].getId());
        appPreference.setName(LoginManager.getInstance().getmLoginResponsePojo().getData()[0].getName());
        appPreference.setEmail(LoginManager.getInstance().getmLoginResponsePojo().getData()[0].getEmail());
        appPreference.setAddress(LoginManager.getInstance().getmLoginResponsePojo().getData()[0].getAddress());
        appPreference.setMobile(LoginManager.getInstance().getmLoginResponsePojo().getData()[0].getMob());
        Toast.makeText(LoginActivity.this, "Login Successful!!!", Toast.LENGTH_SHORT).show();
        finish();
    }

    @Override
    public void onLoginResponseFailed() {
        login_layout.setVisibility(View.VISIBLE);
        signup_loader.setVisibility(View.GONE);
        Toast.makeText(LoginActivity.this, "Incorrect username or password", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onLoginTimeoutReceived() {
        login_layout.setVisibility(View.VISIBLE);
        signup_loader.setVisibility(View.GONE);
        Toast.makeText(LoginActivity.this, R.string.internet_connection_error, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onUserNotExist() {
        login_layout.setVisibility(View.VISIBLE);
        signup_loader.setVisibility(View.GONE);
    }

    class MyTextWatcher implements TextWatcher {

        private View view;

        private MyTextWatcher(View view) {
            this.view = view;
        }

        public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
        }

        public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
        }

        public void afterTextChanged(Editable editable) {
            switch (view.getId()) {
                case R.id.input_layout_mobile:
                    validateMobile();
                    break;
                case R.id.input_layout_password:
                    validatePassword();
                    break;
            }
        }
    }
}
