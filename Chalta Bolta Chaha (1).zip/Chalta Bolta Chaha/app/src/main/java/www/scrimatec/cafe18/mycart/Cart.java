package www.scrimatec.cafe18.mycart;

public class Cart {
    int id;
    String prodId;
    String pname;
    String url;
    String qty;
    String unit;
    String price;

    public Cart() {
    }

    public Cart(int id, String qty, String price) {
        this.id = id;
        this.qty = qty;
        this.price = price;
    }

    public Cart(String prodId, String pname, String url, String qty, String unit, String price) {
        this.prodId = prodId;
        this.pname = pname;
        this.url = url;
        this.qty = qty;
        this.unit = unit;
        this.price = price;
    }

    public Cart(int id, String prodId, String pname, String url, String qty, String unit, String price) {
        this.id = id;
        this.prodId = prodId;
        this.pname = pname;
        this.url = url;
        this.qty = qty;
        this.unit = unit;
        this.price = price;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getProdId() {
        return prodId;
    }

    public void setProdId(String prodId) {
        this.prodId = prodId;
    }

    public String getQty() {
        return qty;
    }

    public void setQty(String qty) {
        this.qty = qty;
    }

    public String getUnit() {
        return unit;
    }

    public void setUnit(String unit) {
        this.unit = unit;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getPname() {
        return pname;
    }

    public void setPname(String pname) {
        this.pname = pname;
    }
}
