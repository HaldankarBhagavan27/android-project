package www.scrimatec.cafe18.order_list;

public class OrderListResponsePojo {
    private Ord_list[] ord_list;

    public Ord_list[] getOrd_list() {
        return ord_list;
    }

    public void setOrd_list(Ord_list[] ord_list) {
        this.ord_list = ord_list;
    }

    @Override
    public String toString() {
        return "ClassPojo [ord_list = " + ord_list + "]";
    }
}
