package www.scrimatec.cafe18.network;

import android.content.Context;
import android.util.Log;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import www.scrimatec.cafe18.utils.MandaiController;

import org.json.JSONObject;

import java.net.MalformedURLException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Pattern;

public class NetworkManager {
    private static NetworkManager mInstance;
    private final static Pattern mPattern = Pattern.compile("<(.+?)>");
    private static final String CONTENT_TYPE = "Content-Type";
    private static final String APPLICATION_JSON_CHARSET_UTF_8 = "application/json; charset=utf-8";

    private static final String BASE_URL = "http://milkbar.scrimatec.com/and_admin1/api/mandai_api.php?filter=";
    private static final String SIGNUP_URL = BASE_URL + "signup";
    private static final String LOGIN_URL = BASE_URL + "login";
    private static final String CATEGOTY_LIST_URL = BASE_URL + "cat_list";
    private static final String PRODUCT_URL = BASE_URL + "prod_list";
    private static final String PRODUCT_DETAILS_URL = BASE_URL + "prod_details";
    private static final String UPDATE_PROFILE_URL = BASE_URL + "update_profile";
    private static final String MY_ORDERS_URL = BASE_URL + "order_list";
    private static final String ORDER_DETAILS_URL = BASE_URL + "order_details";
    private static final String FEEDBACK_URL = BASE_URL + "feedback";
    private static final String ORDER_URL = BASE_URL + "order";
    private static final String AREA_URL = BASE_URL + "area";
    private static final String OTP_URL = BASE_URL + "otp";
    private static final String SEARCH_URL = BASE_URL + "search_prod_list";
    public String getProductSearchUrl() {
        return SEARCH_URL;
    }

    public enum RequestType {SIGNUP, LOGIN, CAT_LIST, PROD_LIST, PROD_DETAILS, UPDATE_PROFILE, MY_ORDERS, ORDER_DETAILS, FEEDBACK, ORDER, AREA, OTP}

    private ArrayList<NetworkResponseListener> mListeners = new ArrayList<NetworkResponseListener>();

    private NetworkManager() {
    }

    public static NetworkManager getInstance() {
        return (mInstance == null) ? mInstance = new NetworkManager() : mInstance;
    }

    public void registerListener(NetworkResponseListener networkResponseListener) {
        if (!mListeners.contains(networkResponseListener)) mListeners.add(networkResponseListener);
    }

    public void deRegisterListener(NetworkResponseListener networkResponseListener) {
        mListeners.remove(networkResponseListener);
    }

    private void sendSuccessfulResponses(String response, RequestType requestType) {
        for (NetworkResponseListener networkResponseListener : mListeners) {
            networkResponseListener.onNetworkResponseReceived(response, requestType);
        }
    }

    private void sendFailedResponses(RequestType requestType) {
        for (NetworkResponseListener networkResponseListener : mListeners) {
            networkResponseListener.onNetworkResponseFailed(requestType);
        }
    }

    public void sendJsonObjectRequest(Context context, int method, String url, final JSONObject payload, final RequestType requestType) {
        Log.d("TAG", "value of payload before sending request " + payload);
        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(method,
                encodeUrl(url), payload,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        Log.d("TAG", response.toString());
                        Log.d("TAG", "onResponse");
                        sendSuccessfulResponses(response.toString(), requestType);
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
                Log.d("TAG", "onErrorResponse");
                sendFailedResponses(requestType);
            }
        }) {
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> params = new HashMap<String, String>();
                params.put(CONTENT_TYPE, APPLICATION_JSON_CHARSET_UTF_8);
                return params;
            }
        };
        Log.d("TAG", "request " + jsonObjectRequest);
        Log.i("TAG", "Body Content type : " + jsonObjectRequest.getBodyContentType());
        Log.i("TAG", "Body : " + jsonObjectRequest.getBody());
        jsonObjectRequest.setRetryPolicy(new DefaultRetryPolicy(60000, DefaultRetryPolicy.DEFAULT_MAX_RETRIES, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        MandaiController.getInstance().addToRequestQueue(jsonObjectRequest);
    }

    public static String getSignupUrl() {
        return SIGNUP_URL;
    }

    public static String getLoginUrl() {
        return LOGIN_URL;
    }

    public static String getCategotyListUrl() {
        return CATEGOTY_LIST_URL;
    }

    public static String getProductUrl() {
        return PRODUCT_URL;
    }

    public static String getProductDetailsUrl() {
        return PRODUCT_DETAILS_URL;
    }

    public static String getUpdateProfileUrl() {
        return UPDATE_PROFILE_URL;
    }

    public static String getMyOrdersUrl() {
        return MY_ORDERS_URL;
    }

    public static String getOrderDetailsUrl() {
        return ORDER_DETAILS_URL;
    }

    public static String getFeedbackUrl() {
        return FEEDBACK_URL;
    }

    public static String getOrderUrl() {
        return ORDER_URL;
    }

    public static String getAreaUrl() {
        return AREA_URL;
    }

    public static String getOtpUrl() {
        return OTP_URL;
    }

    private String encodeUrl(String url) {
        URI uri = null;
        try {
            URL lUrl = new URL(url);
            uri = new URI(lUrl.getProtocol(), lUrl.getUserInfo(),
                    lUrl.getHost(), lUrl.getPort(), lUrl.getPath(),
                    lUrl.getQuery(), lUrl.getRef());
        } catch (URISyntaxException e) {
            e.printStackTrace();
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }
        return uri.toString();
    }
}
