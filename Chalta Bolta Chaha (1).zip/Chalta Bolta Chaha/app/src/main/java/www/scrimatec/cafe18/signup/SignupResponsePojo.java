package www.scrimatec.cafe18.signup;

public class SignupResponsePojo {
    private String st;

    private String id;

    public String getSt() {
        return st;
    }

    public void setSt(String st) {
        this.st = st;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    @Override
    public String toString() {
        return "ClassPojo [st = " + st + "]";
    }
}
