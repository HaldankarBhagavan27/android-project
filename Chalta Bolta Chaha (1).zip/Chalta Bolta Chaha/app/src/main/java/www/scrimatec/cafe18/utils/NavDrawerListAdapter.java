package www.scrimatec.cafe18.utils;

import android.app.Activity;
import android.content.Context;
import android.graphics.Typeface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import www.scrimatec.cafe18.R;

import java.util.ArrayList;

public class NavDrawerListAdapter extends BaseAdapter {

    Context context;
    ArrayList<NavDrawerItem> drawerItemList;
    Typeface font;

    public NavDrawerListAdapter(Context context, ArrayList<NavDrawerItem> listItems) {
        this.context = context;
        this.drawerItemList = listItems;
    }

    @Override
    public int getCount() {
        return drawerItemList.size();
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {


        DrawerItemHolder drawerHolder;
        NavDrawerItem dItem = this.drawerItemList.get(position);
        View view = convertView;
        if (view == null) {
            LayoutInflater inflater = ((Activity) context).getLayoutInflater();
            drawerHolder = new DrawerItemHolder();
            view = inflater.inflate(R.layout.drawer_item_row, parent, false);
            drawerHolder.text = view.findViewById(R.id.drawer_txt_Name);
            drawerHolder.icon = view.findViewById(R.id.drawer_Image);
            drawerHolder.title = view.findViewById(R.id.txt_drawerTitle);
            drawerHolder.itemLayout = view.findViewById(R.id.img_txt_drawerLayout);
            drawerHolder.drawerLine = view.findViewById(R.id.drawer_line);
            view.setTag(drawerHolder);

        } else {
            drawerHolder = (DrawerItemHolder) view.getTag();
        }

        if (dItem.isSpinner()) {
            drawerHolder.itemLayout.setVisibility(LinearLayout.INVISIBLE);
        } else if (dItem.getTitle() != null) {
            drawerHolder.itemLayout.setVisibility(LinearLayout.GONE);
            drawerHolder.title.setVisibility(View.VISIBLE);
            drawerHolder.drawerLine.setVisibility(View.VISIBLE);
            drawerHolder.title.setText(dItem.getTitle());
        } else {
            drawerHolder.itemLayout.setVisibility(LinearLayout.VISIBLE);
            drawerHolder.title.setVisibility(View.GONE);
            drawerHolder.drawerLine.setVisibility(View.GONE);
            drawerHolder.text.setText(dItem.getDrawerText());
            drawerHolder.icon.setImageResource(dItem.getDrawerIcon());
        }
        return view;
    }

    private static class DrawerItemHolder {
        TextView text, title;
        ImageView icon;
        LinearLayout itemLayout;
        View drawerLine;
    }
}
