package www.scrimatec.cafe18.help;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

import www.scrimatec.cafe18.R;

//import uk.co.chrisjenx.calligraphy.CalligraphyContextWrapper;

public class HelpandContactActivity extends AppCompatActivity implements OnMapReadyCallback {
    private Toolbar toolbar;
    private ImageView img_back_arrow;
    private TextView txt_title;
    private RelativeLayout lay_toolbar_cart;
    private GoogleMap mMap;

//    @Override
//    protected void attachBaseContext(Context newBase) {
//        super.attachBaseContext(CalligraphyContextWrapper.wrap(newBase));
//    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_help_and_contact);

        toolbar = findViewById(R.id.app_bar);
        img_back_arrow = toolbar.findViewById(R.id.img_back_arrow);
        img_back_arrow.setVisibility(View.VISIBLE);
        txt_title = toolbar.findViewById(R.id.txt_title);
        txt_title.setText("Contact Us");
        lay_toolbar_cart = toolbar.findViewById(R.id.lay_toolbar_cart);
        lay_toolbar_cart.setVisibility(View.INVISIBLE);

        img_back_arrow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

    }
    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        // Add a marker in Sydney and move the camera
        LatLng MapFragment = new LatLng(21, 57);
        mMap.addMarker(new
                MarkerOptions().position(MapFragment).title("Cafe18"));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(MapFragment));
    }
}
