package www.scrimatec.cafe18.product_details;

public class ProductDetailsResponsePojo {
    private Prod_details[] prod_details;

    public Prod_details[] getProd_details ()
    {
        return prod_details;
    }

    public void setProd_details (Prod_details[] prod_details)
    {
        this.prod_details = prod_details;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [prod_details = "+prod_details+"]";
    }
}
