package www.scrimatec.cafe18.confirm_order;

/**
 * Created by Softdroid on 10/10/2017.
 */

public interface AreaResponseListener {
    void onAreaResponseReceived();
    void onAreaResponseFailed();
    void onAreaResponseTimeout();
}
