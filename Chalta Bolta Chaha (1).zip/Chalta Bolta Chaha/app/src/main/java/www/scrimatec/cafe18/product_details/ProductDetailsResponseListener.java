package www.scrimatec.cafe18.product_details;

public interface ProductDetailsResponseListener {
    void onProductDetailsResponseReceived();

    void onProductDetailsResponseFailed();

    void onProductDetailsResponseTimeout();
}
