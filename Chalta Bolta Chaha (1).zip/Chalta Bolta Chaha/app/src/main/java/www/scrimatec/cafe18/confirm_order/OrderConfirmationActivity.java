package www.scrimatec.cafe18.confirm_order;

import android.app.DatePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.TextInputLayout;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.github.ybq.android.spinkit.SpinKitView;

import www.scrimatec.cafe18.R;
import www.scrimatec.cafe18.login.LoginActivity;
import www.scrimatec.cafe18.mycart.Cart;
import www.scrimatec.cafe18.mycart.CartDatabaseHandler;
import www.scrimatec.cafe18.utils.AppPreference;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

//import uk.co.chrisjenx.calligraphy.CalligraphyContextWrapper;

public class OrderConfirmationActivity extends AppCompatActivity implements View.OnClickListener, OrderResponseListener, AdapterView.OnItemSelectedListener, AreaResponseListener {
    private double totalPrice = 0, minAmount = 0, delivery = 0, totalPayable = 0, tax = 0;
    private LinearLayout confirm_order_layout;
    private Button btn_order;
    private SpinKitView order_loader;
    private TextInputLayout input_layout_name, input_layout_mob, input_layout_addr, input_layout_date, input_layout_pin;
    private EditText edt_name, edt_mob, edt_addr, edt_date, edt_pin;
    private String name, mobile, address, date, string_today, selectedArea;
    private AppPreference appPreference;
    private int year, month, day;
    private CartDatabaseHandler cartDatabaseHandler;
    private Spinner spn_area;
    private Toolbar toolbar;
    private ImageView img_back_arrow;
    private TextView txt_title, txt_price, txt_delivery, txt_tax, txt_total;
    private RelativeLayout lay_toolbar_cart;
    private String[] areas;
    private int selec = 0;

//    @Override
//    protected void attachBaseContext(Context newBase) {
//        super.attachBaseContext(CalligraphyContextWrapper.wrap(newBase));
//    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_confirm_order);

        totalPrice = getIntent().getDoubleExtra("total", 0);
        if (totalPrice == 0) {
            Toast.makeText(this, "Please Add Quantity", Toast.LENGTH_SHORT).show();
            finish();
        }
        appPreference = new AppPreference(OrderConfirmationActivity.this);
        cartDatabaseHandler = new CartDatabaseHandler(OrderConfirmationActivity.this);
        confirm_order_layout = findViewById(R.id.confirm_order_layout);
        input_layout_name = findViewById(R.id.input_layout_name);
        input_layout_mob = findViewById(R.id.input_layout_mob);
        input_layout_addr = findViewById(R.id.input_layout_addr);
        input_layout_date = findViewById(R.id.input_layout_date);
        input_layout_pin = findViewById(R.id.input_layout_pin);
        edt_name = findViewById(R.id.edt_name);
        edt_mob = findViewById(R.id.edt_mob);
        edt_addr = findViewById(R.id.edt_addr);
        edt_date = findViewById(R.id.edt_date);
        edt_date.setOnClickListener(this);
        edt_pin = findViewById(R.id.edt_pin);
        btn_order = findViewById(R.id.btn_order);
        btn_order.setOnClickListener(this);
        order_loader = findViewById(R.id.order_loader);
        spn_area = findViewById(R.id.spn_area);
        toolbar = findViewById(R.id.app_bar);
        img_back_arrow = toolbar.findViewById(R.id.img_back_arrow);
        img_back_arrow.setVisibility(View.VISIBLE);
        img_back_arrow.setOnClickListener(this);
        txt_title = toolbar.findViewById(R.id.txt_title);
        txt_title.setText("Delivery Details");
        txt_price = findViewById(R.id.txt_price);
        txt_price.setText("₹ " + totalPrice);
        txt_delivery = findViewById(R.id.txt_delivery);
        txt_tax = findViewById(R.id.txt_tax);
        txt_total = findViewById(R.id.txt_total);
        txt_total.setText("₹ " + totalPrice);
        lay_toolbar_cart = toolbar.findViewById(R.id.lay_toolbar_cart);
        lay_toolbar_cart.setVisibility(View.INVISIBLE);
        string_today = new SimpleDateFormat("dd/MM/yyyy").format(new Date());
        OrderManager.getInstance().registerOrderListener(this);
        OrderManager.getInstance().registerAreaListener(this);
        OrderManager.getInstance().sendAreaRequest(OrderConfirmationActivity.this);
    }

    @Override
    protected void onResume() {
        super.onResume();
        AppPreference appPreference = new AppPreference(this);
        if (!appPreference.getUserId().equals("0")) {
            edt_name.setText(appPreference.getName());
            edt_mob.setText(appPreference.getMobile());
            edt_addr.setText(appPreference.getAddress());
        }
    }

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.btn_order) {
            sendOrder();
        } else if (v.getId() == R.id.edt_date) {
            View view = this.getCurrentFocus();
            if (view != null) {
                InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
            }

            final Calendar c = Calendar.getInstance();
            year = c.get(Calendar.YEAR);
            month = c.get(Calendar.MONTH);
            day = c.get(Calendar.DAY_OF_MONTH);
            DatePickerDialog datePickerDialog = new DatePickerDialog(this,
                    new DatePickerDialog.OnDateSetListener() {

                        @Override
                        public void onDateSet(DatePicker view, int year,
                                              int monthOfYear, int dayOfMonth) {
                            String dd = "", mm = "";
                            if (dayOfMonth < 10) {
                                dd = "0" + dayOfMonth;
                            } else {
                                dd = String.valueOf(dayOfMonth);
                            }

                            if ((monthOfYear + 1) < 10) {
                                mm = "0" + (monthOfYear + 1);
                            } else {
                                mm = String.valueOf(monthOfYear + 1);
                            }
                            edt_date.setText(dd + "/" + mm + "/" + year);
                        }
                    }, year, month, day);
            datePickerDialog.getDatePicker().setMinDate(System.currentTimeMillis() - 1000);
            datePickerDialog.show();
        } else if (v.getId() == R.id.img_back_arrow) {
            finish();
        }
    }

    private void sendOrder() {
        View view = this.getCurrentFocus();
        if (view != null) {
            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
        }
        if (!validateName()) {
            return;
        }
        if (!validateMobile()) {
            return;
        }
        if (!validateAddress()) {
            return;
        }
        if (!validatePin()) {
            return;
        }
        if (!validateDate()) {
            return;
        }
        name = edt_name.getText().toString().trim();
        mobile = edt_mob.getText().toString().trim();
        address = edt_addr.getText().toString().trim();
        date = edt_date.getText().toString().trim();
        if (appPreference.getUserId().equals("0")) {
            Intent intent = new Intent(OrderConfirmationActivity.this, LoginActivity.class);
            startActivity(intent);
        } else {
            String pid = "", price = "", quantity = "";
            ArrayList<Cart> cartList = new ArrayList<Cart>();
            cartList = cartDatabaseHandler.getAllProducts();
            for (int i = 0; i < cartList.size(); i++) {
                if (i == 0) {
                    pid = cartList.get(i).getProdId();
                    price = cartList.get(i).getPrice();
                    quantity = cartList.get(i).getQty();
                } else {
                    pid = pid + "#" + cartList.get(i).getProdId();
                    price = price + "#" + cartList.get(i).getPrice();
                    quantity = quantity + "#" + cartList.get(i).getQty();
                }
            }
            OrderManager.getInstance().sendOrderRequest(OrderConfirmationActivity.this, pid, price, quantity, name, mobile, address + "\nArea: " + areas[selec], date, appPreference.getUserId(), String.valueOf(delivery), String.valueOf(tax));
            confirm_order_layout.setVisibility(View.GONE);
            btn_order.setVisibility(View.GONE);
            order_loader.setVisibility(View.VISIBLE);
        }
    }

    private boolean validateName() {
        if (edt_name.getText().toString().trim().isEmpty()) {
            input_layout_name.setError("Please Enter Name");
            requestFocus(edt_name);
            return false;
        } else {
            if (edt_name.getText().toString().trim().length() > 2) {
                input_layout_name.setErrorEnabled(false);
                return true;
            } else {
                input_layout_name.setError("Invalid Name");
                requestFocus(edt_name);
                return false;
            }
        }
    }

    private boolean validateMobile() {
        if (edt_mob.getText().toString().trim().isEmpty()) {
            input_layout_mob.setError("Please Enter Mobile Number");
            requestFocus(edt_mob);
            return false;
        } else {
            if (edt_mob.getText().toString().trim().length() == 10) {
                if (edt_mob.getText().toString().trim().startsWith("00")) {
                    input_layout_mob.setError("Invalid Mobile Number");
                    return false;
                } else {
                    input_layout_mob.setErrorEnabled(false);
                    return true;
                }
            } else {
                input_layout_mob.setError("Invalid Mobile Number");
                requestFocus(edt_mob);
                return false;
            }
        }
    }

    private boolean validateAddress() {
        if (edt_addr.getText().toString().trim().isEmpty()) {
            input_layout_addr.setError("Please Enter Address");
            requestFocus(edt_addr);
            return false;
        } else {
            if (edt_addr.getText().toString().trim().length() > 2) {
                input_layout_addr.setErrorEnabled(false);
                return true;
            } else {
                input_layout_addr.setError("Invalid Address");
                requestFocus(edt_addr);
                return false;
            }
        }
    }

    private boolean validatePin() {
        if (edt_pin.getText().toString().trim().isEmpty()) {
            input_layout_pin.setError("Please Enter PinCode");
            requestFocus(edt_pin);
            return false;
        } else {
            if (edt_pin.getText().toString().trim().length() == 6) {
                input_layout_pin.setErrorEnabled(false);
                return true;
            } else {
                input_layout_pin.setError("Invalid PinCode");
                requestFocus(edt_pin);
                return false;
            }
        }
    }

    private boolean validateDate() {
        if (edt_date.getText().toString().trim().isEmpty()) {
            input_layout_date.setError("Please Enter Date");
            requestFocus(edt_date);
            return false;
        } else {
            Date today = stringToDate(string_today);
            Date deliveryDate = stringToDate(edt_date.getText().toString());
            if (edt_date.getText().toString().trim().length() > 0) {
                if (compareTwoDates(deliveryDate, today) >= 0) {
                    input_layout_date.setErrorEnabled(false);
                    return true;
                } else {
                    input_layout_date.setError("Please enter tomorrow onwards date");
                    requestFocus(edt_date);
                    return false;
                }
            } else {
                input_layout_date.setError("Invalid Date");
                requestFocus(edt_date);
                return false;
            }
        }
    }

    private void requestFocus(View view) {
        if (view.requestFocus()) {
            getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE);
        }
    }

    public static int compareTwoDates(Date date1, Date date2) {
        if (date1.after(date2)) {
            return 1;
        } else if (date1.equals(date2)) {
            return 0;
        } else {
            return -1;
        }
    }

    public Date stringToDate(String str_date) {
        Date date = null;
        SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy");
        try {
            date = format.parse(str_date);
            System.out.println(date);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return date;
    }

    @Override
    public void onOrderResponseReceived() {
        Toast.makeText(this, "Order placed successfully", Toast.LENGTH_SHORT).show();
        Toast.makeText(this, "You can check order status in My Orders", Toast.LENGTH_SHORT).show();
        confirm_order_layout.setVisibility(View.VISIBLE);
        btn_order.setVisibility(View.VISIBLE);
        order_loader.setVisibility(View.GONE);
        Intent intent = new Intent(this, InvoiceActivity.class);
        intent.putExtra("name", name);
        intent.putExtra("address", address);
        intent.putExtra("delivery", delivery);
        startActivity(intent);
        finish();
    }

    @Override
    public void onOrderResponseFailed() {
        confirm_order_layout.setVisibility(View.VISIBLE);
        btn_order.setVisibility(View.VISIBLE);
        order_loader.setVisibility(View.GONE);
        Toast.makeText(this, "Please check quantity\nplease try again", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onOrderResponseTimeout() {
        Toast.makeText(this, "Order placed successfully", Toast.LENGTH_SHORT).show();
        Toast.makeText(this, "You can check order status in My Orders", Toast.LENGTH_SHORT).show();
        confirm_order_layout.setVisibility(View.VISIBLE);
        btn_order.setVisibility(View.VISIBLE);
        order_loader.setVisibility(View.GONE);
        Intent intent = new Intent(this, InvoiceActivity.class);
        intent.putExtra("name", name);
        intent.putExtra("address", address);
        intent.putExtra("delivery", delivery);
        startActivity(intent);
        finish();
//        Intent intent=new Intent(this, MainActivity.class);
//        startActivity(intent);
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        selec = position;
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }

    @Override
    public void onAreaResponseReceived() {
        areas = new String[OrderManager.getInstance().getmAreaResponsePojo().getArea_name().length];
        for (int i = 0; i < OrderManager.getInstance().getmAreaResponsePojo().getArea_name().length; i++) {
            areas[i] = OrderManager.getInstance().getmAreaResponsePojo().getArea_name()[i].getArea();
        }
        ArrayAdapter<String> areaAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, areas);
        areaAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spn_area.setAdapter(areaAdapter);
        tax = Integer.parseInt(OrderManager.getInstance().getmAreaResponsePojo().getCharges()[0].getTax());
        delivery = Integer.parseInt(OrderManager.getInstance().getmAreaResponsePojo().getCharges()[0].getDelivery_charges());
        minAmount = Integer.parseInt(OrderManager.getInstance().getmAreaResponsePojo().getCharges()[0].getMin_order());
        if (totalPrice < minAmount)
            totalPayable = totalPrice + delivery + tax;
        else {
            totalPayable = totalPrice;
            delivery = 0;
        }
        txt_tax.setText("₹ " + tax);
        txt_delivery.setText("₹ " + delivery);
        txt_total.setText("₹ " + totalPayable);
    }

    @Override
    public void onAreaResponseFailed() {

    }

    @Override
    public void onAreaResponseTimeout() {

    }
}