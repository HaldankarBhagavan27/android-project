package www.scrimatec.cafe18.confirm_order;

/**
 * Created by Softdroid on 10/10/2017.
 */

public class Area_name {
    String area;

    public String getArea() {
        return area;
    }

    public void setArea(String area) {
        this.area = area;
    }
}
