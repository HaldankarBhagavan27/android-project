package www.scrimatec.cafe18.main;

public class CategoryResponsePojo {
    private Cat_list[] cat_list;

    public Cat_list[] getCat_list() {
        return cat_list;
    }

    public void setCat_list(Cat_list[] cat_list) {
        this.cat_list = cat_list;
    }

    @Override
    public String toString() {
        return "ClassPojo [cat_list = " + cat_list + "]";
    }
}
