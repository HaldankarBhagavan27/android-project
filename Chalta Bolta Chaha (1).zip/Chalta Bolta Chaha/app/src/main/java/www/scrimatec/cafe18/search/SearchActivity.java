package www.scrimatec.cafe18.search;

import android.support.v4.view.MenuItemCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.SearchView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.github.ybq.android.spinkit.SpinKitView;
import com.google.gson.Gson;

import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

import www.scrimatec.cafe18.R;
import www.scrimatec.cafe18.network.NetworkManager;
import www.scrimatec.cafe18.product_list.ProductListAdapter;
import www.scrimatec.cafe18.product_list.ProductListResponsePojo;
import www.scrimatec.cafe18.utils.MandaiController;

public class SearchActivity extends AppCompatActivity {

    private ListView productList;
    private TextView txt_empty_list;
    private SpinKitView main_loader;
    private Toolbar toolbar;
    private ProductListAdapter productListAdapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);
        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("Search Product");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        productList = findViewById(R.id.productList);
        main_loader = findViewById(R.id.main_loader);
        main_loader.setVisibility(View.VISIBLE);
        txt_empty_list = findViewById(R.id.txt_empty_list);
        fetchProducts();
    }

    private void fetchProducts() {
        Map<String, String> jsonParams = new HashMap<String, String>();
        jsonParams.put("search", "Rice");
        Log.d("TAGG", "jsonParams: " + jsonParams.toString());
        JsonObjectRequest objectRequest = new JsonObjectRequest(Request.Method.POST, NetworkManager.getInstance().getProductSearchUrl(), new JSONObject(jsonParams), new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                Log.d("TUSHAR", "response: " + response);
                Gson gson = new Gson();
                try {
                    ProductListResponsePojo mProductListResponsePojo = gson.fromJson(response.toString(), ProductListResponsePojo.class);
                    if (mProductListResponsePojo != null) {
                        if (mProductListResponsePojo.getProd_list() != null)
                            if (!mProductListResponsePojo.getProd_list().isEmpty()) {
                                productListAdapter = new ProductListAdapter(SearchActivity.this, mProductListResponsePojo.getProd_list());
                                productList.setAdapter(productListAdapter);
                                productList.setEmptyView(txt_empty_list);
                                main_loader.setVisibility(View.GONE);
                            }
                    }
                }catch (Exception e){

                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.e("TAG", "onErrorResponse: ", error);
            }
        }) {
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                HashMap<String, String> header = new HashMap<String, String>();
                header.put("Content-Type", "application/json");
                return header;
            }
        };
        MandaiController.getInstance().addToRequestQueue(objectRequest, "header");
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.list_gird_menu, menu);
        MenuItem searchItem = menu.findItem(R.id.action_search);
        SearchView searchView = (SearchView) MenuItemCompat.getActionView(searchItem);
        ((EditText) searchView.findViewById(android.support.v7.appcompat.R.id.search_src_text)).setHintTextColor(getResources().getColor(R.color.white));
        ((EditText) searchView.findViewById(android.support.v7.appcompat.R.id.search_src_text)).setTextColor(getResources().getColor(R.color.white));
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {

            @Override
            public boolean onQueryTextSubmit(String query) {

                return false;
            }

            @Override
            public boolean onQueryTextChange(String searchQuery) {
                try{
                    productListAdapter.getFilter(searchQuery.trim());
                    productList.invalidate();
                }catch (NullPointerException e){
                    Toast.makeText(SearchActivity.this, "There should is no data for sorting", Toast.LENGTH_SHORT).show();
                }
                return true;
            }
        });

        return true;
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        switch (item.getItemId()){
            case android.R.id.home:
                onBackPressed();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }

    }
}
