package www.scrimatec.cafe18.main;

import android.content.Context;

import com.android.volley.Request;
import com.google.gson.Gson;
import www.scrimatec.cafe18.network.NetworkManager;
import www.scrimatec.cafe18.network.NetworkResponseListener;

public class CategoryManager implements NetworkResponseListener {
    private static CategoryManager mInstance;
    private CategoryResponseListener mCategoryResponseListener;
    private CategoryResponsePojo mCategoryResponsePojo;

    public static CategoryManager getInstance() {
        return (mInstance == null) ? mInstance = new CategoryManager() : mInstance;
    }

    public void registerCatListener(CategoryResponseListener categoryResponseListener) {
        NetworkManager.getInstance().registerListener(this);
        mCategoryResponseListener = categoryResponseListener;
    }

    public void deregisterCatListener() {
        NetworkManager.getInstance().deRegisterListener(this);
        mCategoryResponseListener = null;
    }

    public void sendCatRequest(Context context) {
        NetworkManager.getInstance().sendJsonObjectRequest(context, Request.Method.POST, NetworkManager.getInstance().getCategotyListUrl(), null, NetworkManager.RequestType.CAT_LIST);
    }

    public CategoryResponsePojo getmCategoryResponsePojo() {
        return mCategoryResponsePojo;
    }

    @Override
    public void onNetworkResponseReceived(String response, NetworkManager.RequestType requestType) {
        Gson gson = new Gson();
        if (requestType == NetworkManager.RequestType.CAT_LIST) {
            if (mCategoryResponseListener == null)
                return;
            mCategoryResponsePojo = gson.fromJson(response, CategoryResponsePojo.class);
            if (mCategoryResponsePojo.getCat_list().length > 0) {
                mCategoryResponseListener.onCategoryResponseReceived();
            } else {
                mCategoryResponseListener.onCategoryResponseFailed();
            }
        }
    }

    @Override
    public void onNetworkResponseFailed(NetworkManager.RequestType requestType) {
        if (requestType == NetworkManager.RequestType.CAT_LIST) {
            mCategoryResponseListener.onCategoryResponseTimeout();
        }
    }
}