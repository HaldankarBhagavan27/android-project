package www.scrimatec.cafe18.product_details;

public class ProductDetailsRequestPojo {
    String id;

    public ProductDetailsRequestPojo(String id) {
        this.id = id;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }
}
