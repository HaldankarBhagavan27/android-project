package www.scrimatec.cafe18.main;

public interface CategoryResponseListener {
    void onCategoryResponseReceived();

    void onCategoryResponseFailed();

    void onCategoryResponseTimeout();
}
