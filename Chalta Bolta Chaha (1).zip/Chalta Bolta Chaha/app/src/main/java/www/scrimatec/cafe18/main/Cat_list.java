package www.scrimatec.cafe18.main;

public class Cat_list {
    private String img_url;

    private String id;

    private String name;

    private String mar_name;

    public String getImg_url() {
        return img_url;
    }

    public void setImg_url(String img_url) {
        this.img_url = img_url;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getMar_name() {
        return mar_name;
    }

    public void setMar_name(String mar_name) {
        this.mar_name = mar_name;
    }

    @Override
    public String toString() {
        return "ClassPojo [img_url = " + img_url + ", id = " + id + ", name = " + name + ", mar_name = " + mar_name + "]";
    }
}
