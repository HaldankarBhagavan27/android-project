package www.scrimatec.cafe18.signup;

public interface SignupResponseListener {
    void onSignupResponseReceived();

    void onSignupResponseFailed();

    void onUserAlreadyExsist();

    void onSignupResponseTimeout();
}
