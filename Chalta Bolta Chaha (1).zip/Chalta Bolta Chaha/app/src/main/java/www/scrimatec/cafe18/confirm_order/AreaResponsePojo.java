package www.scrimatec.cafe18.confirm_order;

/**
 * Created by Softdroid on 10/10/2017.
 */

public class AreaResponsePojo {
    private Charges[] charges;

    private Area_name[] area_name;

    private String st;

    public Charges[] getCharges() {
        return charges;
    }

    public void setCharges(Charges[] charges) {
        this.charges = charges;
    }

    public Area_name[] getArea_name() {
        return area_name;
    }

    public void setArea_name(Area_name[] area_name) {
        this.area_name = area_name;
    }

    public String getSt() {
        return st;
    }

    public void setSt(String st) {
        this.st = st;
    }

    @Override
    public String toString() {
        return "ClassPojo [charges = " + charges + ", area_name = " + area_name + ", st = " + st + "]";
    }
}
